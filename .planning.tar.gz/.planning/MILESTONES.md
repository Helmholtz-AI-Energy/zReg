# Milestones

## v1.0 Consolidation (Shipped: 2026-04-09)

**Phases completed:** 5 phases, 13 plans, 18 tasks

**Key accomplishments:**

- _validate_tensors() with NaN/inf and device-mismatch detection wired into 6 entry points (CPD, BaseWD, minkowski_distance, pairwise_distance_matrix) with 13 tests covering unit and integration scenarios
- ZREG_LOG_LEVEL env var and zreg.set_log_level() added; Python 3.8 conditional importlib block and dead importlib-metadata dependency removed
- Fixed MaxSWD gradient flow via in-place projection update and GSWD default degree propagation through pairwise_distance_matrix
- RigidCPD scale computation guarded against division by zero with torch.clamp, formula verified against Myronenko & Song 2010, and 3 regression tests added
- Removed redundant normalize_point_cloud from rbf_kernel; normalization now cached once per set_source in NonRigidCPD/ConstrainedNonRigidCPD
- One-liner:
- Extended MstepResult with 5-field namedtuple (n_iters, sigma2_history) and added torch.clamp sigma2 safety after each M-step with one-time WARNING log
- w-coordinate clamping with torch.finfo eps in transform_points_homogeneous, plus det/cond post-composition validation raising ValueError in RigidTransformation.__mul__
- Task 1 — ASWD tempfile auto-cleanup (`sw_varients.py`):
- One-liner:
- CPD numerical stability tests for extreme/degenerate inputs, 3-chain transform composition invariant tests, and CPU/GPU device handling tests
- DTW regression tests covering manhattan/cpd/minkowski metrics, windowed asymmetric trajectories, and single-timepoint boundary paths
- Empty-source guard in transfer_colors plus 8 edge case tests covering empty, single-point, and dimension-mismatched inputs

---
