# zReg

## Current State

**Shipped:** v1.0 Consolidation — 2026-04-09

zReg is a Python library for GPU-accelerated 3D point cloud registration, temporal alignment, and color (celltype) transfer using PyTorch. The v1.0 consolidation milestone addressed all concerns from codebase mapping: fixing 5 bugs, adding input validation across the public API, improving code quality and robustness, enhancing CPD with convergence diagnostics, and closing test gaps with 275 passing regression tests.

## What This Is

A Python library for GPU-accelerated 3D point cloud registration, temporal alignment, and color (celltype) transfer using PyTorch. Supports CPD registration (rigid, affine, non-rigid), sliced Wasserstein distance variants, dynamic time warping, MPI-distributed pairwise distance computation, and geometric transformations. Built for scientific computing with Open3D and torch_cluster interoperability.

## Core Value

Every existing capability works correctly, fails informatively, and is covered by tests.

## Requirements

### Validated

- ✓ Coherent Point Drift (CPD) registration (rigid, affine, non-rigid) — existing
- ✓ Sliced Wasserstein Distance variants (SWD, ASWD, OSWD, GSWD, PSWD) — existing
- ✓ Dynamic Time Warping for temporal alignment — existing
- ✓ Pairwise distance matrix computation with optional MPI — existing
- ✓ Color (celltype) transfer between aligned point clouds — existing
- ✓ Point cloud downsampling (FPS, random, uniform) — existing
- ✓ Geometric transformations (rigid, affine, non-rigid, TPS, combined) — existing
- ✓ Open3D and torch_cluster interoperability — existing
- ✓ Data loading from MATLAB/CSV formats — existing
- ✓ Input validation (NaN/inf, device mismatch) at all public API entry points — v1.0
- ✓ MaxSWD, RigidCPD scale, GSWD degree — all fixed and regression-tested — v1.0
- ✓ DTW path reconstruction — boundary and windowed edge cases fixed — v1.0
- ✓ Homogeneous coordinate stability — w-clamping + composition validation — v1.0
- ✓ CPD convergence diagnostics (n_iters, sigma2_history) and sigma2 clamping — v1.0
- ✓ ASWD tempfile auto-cleanup, MPI row-only communication — v1.0
- ✓ Color transfer enum dispatch and strict pmat shape validation — v1.0
- ✓ Configurable logging (ZREG_LOG_LEVEL env var, set_log_level() API) — v1.0
- ✓ Python 3.8 compat code removed (3.9+ minimum enforced) — v1.0
- ✓ RBF kernel normalization cached once per set_source — v1.0
- ✓ 275 regression tests covering all fixed subsystems — v1.0

### Active

- [ ] Property-based testing with Hypothesis for transform and distance metric invariants (QOL-01)
- [ ] Performance regression tests with pytest-benchmark (QOL-02)
- [ ] py.typed marker for mypy/pyright downstream support (QOL-03)
- [ ] Structured result objects for all registration return values (QOL-04)

### Out of Scope

- Alignment quality metrics (TRE, chamfer distance) — new feature, not consolidation
- Uncertainty quantification for transformations — new feature, not consolidation
- Color transfer occlusion handling — new feature, not consolidation
- Full MPI refactoring (hierarchical communication) — beyond quick wins
- Sparse matrix storage for large distance matrices — beyond quick wins
- Replacing Open3D/torch_cluster with pure PyTorch — major architectural change
- Batch/vectorized pairwise distance computation — beyond quick wins

## Context

- Brownfield Python library for scientific computing (3D point cloud analysis)
- Built on PyTorch with Open3D interoperability
- Supports optional MPI for distributed computation
- Python 3.9+ (3.8 compat code removed in v1.0)
- Shipped v1.0 with ~10,270 net insertions across 48 files
- 275 passing regression tests after v1.0 consolidation
- Known tech debt: VALIDATION.md stale for phases 01-02; no VALIDATION.md for phases 03-05; non-square pmat transpose path covered by code review only

## Constraints

- **Backwards compatibility**: Public API signatures must not break without deprecation
- **Dependencies**: Keep Open3D and torch_cluster as-is; improve error handling around them
- **Performance scope**: Quick wins only (caching, removing redundancy)
- **Python version**: 3.9+

## Key Decisions

| Decision | Rationale | Outcome |
|----------|-----------|---------|
| Fix MaxSWD rather than remove | User wants full distance metric coverage | ✓ Good — in-place projection update resolved gradient flow |
| Quick-win performance only | Avoid scope creep into major refactoring | ✓ Good — RBF caching was sufficient improvement |
| Keep Open3D/torch_cluster | Improve error handling, not replace dependencies | ✓ Good — error handling improved without breakage |
| Skip new features | Focus on fixing what exists, not adding capabilities | ✓ Good — 23 requirements satisfied cleanly |
| All tests deferred to Phase 5 | Tests verify actual fixes, not pre-fix behavior | ✓ Good — clean TDD cycle per phase then full regression |
| Phases 2 and 4 ran in parallel | Both depend only on Phase 1 | ✓ Good — no conflicts, reduced elapsed time |
| sigma2 clamped to dtype.eps | Avoids log(0) without arbitrary floor | ✓ Good — torch.finfo(dtype).eps is dtype-adaptive |
| w-clamped to torch.finfo(dtype).eps | Prevents inf/NaN in homogeneous division | ✓ Good — mirrors sigma2 clamping pattern |
| ValueError (not warning) in __mul__ | Silent corruption worse than loud failure | ✓ Good — user sees clear det/cond values in error |
| pmat strict validation (no auto-transpose) | 'looks transposed' hint is safer than silent correction | ✓ Good — preserves data integrity |
| MPI allgather+sum (not allreduce) | Each rank zeros non-computed entries | ✓ Good — correct merge with minimal message size |

---
*Last updated: 2026-04-09 after v1.0 milestone*
