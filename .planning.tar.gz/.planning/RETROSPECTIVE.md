# Project Retrospective

*A living document updated after each milestone. Lessons feed forward into future planning.*

## Milestone: v1.0 — Consolidation

**Shipped:** 2026-04-09
**Phases:** 5 | **Plans:** 13 | **Tasks:** 18

### What Was Built

- `_validate_tensors()` wired into all 6 public API entry points — NaN/inf and device-mismatch detection with informative errors
- Fixed 5 bugs: MaxSWD gradient flow, RigidCPD scale formula, GSWD degree default, DTW backtrace dead-ends, homogeneous coordinate NaN/inf
- CPD convergence diagnostics (`n_iters`, `sigma2_history`) and sigma2 safety clamping with warnings
- ASWD tempfile auto-cleanup, MPI row-only allgather, color transfer enum dispatch, downsampling debug logging
- 275 passing regression tests covering all fixed subsystems across 3 test plans

### What Worked

- **Foundation-first phase order**: Shipping validation utilities (Phase 1) before any fixes meant all subsequent phases could use consistent error checking. No rework needed.
- **TDD per plan**: Writing failing tests before implementation caught contract mismatches early (e.g., MaxSWD in-place vs. copy semantics, pmat transpose ambiguity).
- **Parallel phase execution**: Phases 2 and 4 ran independently after Phase 1 with no conflicts — good dependency modeling paid off.
- **Deferring tests to Phase 5**: Tests verified the actual fixed implementations, not intermediate state. Clean regression baseline.
- **Code review for ambiguous changes**: w-clamping dtype selection (`torch.finfo(dtype).eps` vs. hardcoded), pmat strict validation vs. auto-transpose — these were caught before implementation by reading paper/existing patterns.

### What Was Inefficient

- **VALIDATION.md stale for Phases 01-02**: Templates were created at plan time but never updated after execution. VERIFICATION.md independently confirmed all truths, but Nyquist docs are misleading for future readers. Should update VALIDATION.md immediately after plan execution.
- **Phases 03-05 had no VALIDATION.md**: Nyquist pre-planning was skipped under time pressure. All verification happened post-hoc in VERIFICATION.md. Functional but documentation debt accumulated.
- **Plan 05-03 delivered 5 of 8 planned test methods**: 3 coverage tests were skipped (all `must_haves.truths` satisfied). Slightly over-scoped the plan initially.

### Patterns Established

- `_validate_tensors(*tensors, names, check_finite, check_device)` — single validation call point for all public API entry points
- `torch.clamp(x, min=torch.finfo(x.dtype).eps)` — dtype-adaptive epsilon clamping (used for sigma2 and w-coordinate)
- Pre-normalize data at call site, pass normalized data to kernel (`rbf_kernel` now pure)
- `try/except ValueError` around enum normalization to accept both string and enum inputs
- `defaults=(None, None)` on namedtuple for optional diagnostic fields (backwards compat)
- TDD cycle: write failing tests → implement → verify tests pass → write SUMMARY.md

### Key Lessons

1. **Model downstream consumers before API changes**: The `rbf_kernel` purity change required updating 3 call sites. Grep for usages before changing function contracts.
2. **Strict validation > silent correction**: The pmat "looks transposed" hint is more valuable than auto-transposing — users need to know their data is wrong, not have it silently fixed.
3. **In-place updates preserve optimizer state**: MaxSWD projection update must use `.data` assignment to preserve Adam's parameter reference. `param = new_value` breaks the optimizer.
4. **namedtuple defaults= for non-breaking extension**: Adding optional diagnostic fields to MstepResult with `defaults=(None, None)` kept all 9 existing 3-arg call sites valid.
5. **Subprocess for import-time env vars**: `ZREG_LOG_LEVEL` is read at import time, so tests using `os.environ` patching in-process don't work. Subprocess isolation is required.

### Cost Observations

- Model: claude-sonnet-4-6 (quality profile)
- Sessions: 1 intensive session (2026-04-09)
- Notable: Full 23-requirement consolidation milestone completed in a single day — well-scoped planning with clear dependency ordering made execution predictable

---

## Cross-Milestone Trends

### Process Evolution

| Milestone | Phases | Plans | Key Change |
|-----------|--------|-------|------------|
| v1.0 | 5 | 13 | First milestone — established TDD cycle and foundation-first ordering |

### Cumulative Quality

| Milestone | Tests Added | Requirements | Tech Debt |
|-----------|-------------|--------------|-----------|
| v1.0 | 275 | 23/23 | 7 items (all doc/observability, non-blocking) |
