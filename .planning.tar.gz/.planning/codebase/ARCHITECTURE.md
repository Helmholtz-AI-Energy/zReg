# Architecture

**Analysis Date:** 2026-04-10

## Executive Summary

zReg is a flat-module scientific Python library for GPU-accelerated 3D point cloud registration, temporal alignment, and color transfer. There are no layered abstractions or dependency-injection frameworks — each module is a coherent, independently importable unit that exposes a small public API surface. The central architectural characteristic is a PyTorch-native data model (`zRegPointCloud`) that flows through every algorithm unchanged.

---

## Pattern Overview

**Overall:** Procedural + OOP hybrid library (no framework, no service layer)

**Key Characteristics:**
- Each domain concern maps 1:1 to a source module (e.g., `cpd.py` owns all CPD logic)
- Data flows as PyTorch tensors or `zRegPointCloud` dicts; no internal data bus or event system
- Modules are largely independent; the main dependency chain is: `validation` ← `utils` ← `distances` / `transforms` ← `cpd` ← `pairwise_distance_matrix` ← `dtw`
- Optional GPU acceleration is handled transparently inside modules (`torch_cluster`, CUDA tensors)
- MPI distribution is an opt-in toggle in `pairwise_distance_matrix`; gated by `NOMPI` env var

---

## Modules and Their Roles

**`src/zreg/dataset.py`** — Data Model and I/O
- Purpose: Defines `zRegPointCloud` (the canonical data container) and loaders
- `zRegPointCloud(dict)`: a typed dict with keys `pos`, `color`, `id`, `fps-idx` backed by `torch.Tensor`
- Loaders: `load_data_from_tracklets()` (MATLAB `.mat` → dict-of-`zRegPointCloud`), `load_shah_from_csv()` (CSV format)
- Conversion utilities: `zreg_to_open3d()`, `open3d_to_zreg()` — bridge to Open3D tensor point clouds
- `.to(device)` method on `zRegPointCloud` moves all tensor fields in one call

**`src/zreg/validation.py`** — Cross-Cutting Input Guard
- Purpose: One function `_validate_tensors()` called at every public API boundary
- Checks: NaN/inf presence, device consistency across multiple tensors
- Called at the top of `cpd.py::set_source()`, `distances/general.py`, `distances/sw_varients.py::BaseWD.forward()`, `pairwise_distance_matrix.py`

**`src/zreg/utils.py`** — Shared Math Primitives
- Purpose: Kernel functions, normalization, and geometric helpers used across modules
- Key exports: `squared_kernel`, `rbf_kernel`, `tps_kernel`, `normalize_point_cloud`, `normalize_to_pc_w_most_points`, `undo_normalize`, `generate_random_rotation_matrix`
- No domain logic; pure tensor math

**`src/zreg/transforms.py`** — Transformation Hierarchy
- Purpose: Composable transformation objects applied to `zRegPointCloud` or raw tensors
- Base class `TransformBase` (plain Python object) with abstract `_transform()` and a public `transform()` that handles extra feature columns (e.g., color appended beyond xyz)
- Concrete classes:
  - `RigidTransformation` — rotation + translation + scale; supports `.inverse()` and `__mul__` composition with determinant/condition validation
  - `AffineTransformation` — full 3×3 affine matrix + translation
  - `NonRigidTransformation` — RBF kernel deformation field
  - `CombinedTransformation` — rigid + non-rigid additive term
  - `TPSTransformation` — Thin Plate Spline; requires SVD-based `prepare()` call
- `transform_points_homogeneous()` — standalone 4×4 matrix application handling both `zRegPointCloud` and `o3d.t.geometry.PointCloud`

**`src/zreg/cpd.py`** — Coherent Point Drift Registration (EM Algorithm)
- Purpose: Point cloud spatial registration via EM; the largest module (1,263 lines)
- Design: Abstract base `CoherentPointDrift` implements the E-step and EM loop; subclasses implement M-step
  - `RigidCPD` → `RigidTransformation`
  - `AffineCPD` → `AffineTransformation`
  - `NonRigidCPD` → `NonRigidTransformation`
  - `ConstrainedNonRigidCPD` → constrained variant
- Named tuples carry results: `EstepResult(pt1, p1, px, n_p, pmat)`, `MstepResult(transformation, sigma2, q, n_iters, sigma2_history)`
- Public entry point: `cpd_registration(source, target, tf_type_name, ...)` — factory that selects and runs the correct subclass
- `init_cpd_from_existing()` — restart from a prior transformation
- `torch.set_float32_matmul_precision("high")` set module-level for performance

**`src/zreg/distances/`** — Distance Metrics Subpackage
- `__init__.py` re-exports everything from both submodules (star import)
- `distances/general.py`: `euclidean_distance`, `manhattan_distance`, `minkowski_distance` — thin wrappers around `torch.cdist` with optional normalization
- `distances/sw_varients.py`: Six `nn.Module` subclasses of `BaseWD`:
  - `SlicedWassersteinDistance` (SWD)
  - `AdaptiveSlicedWassersteinDistance` (ASWD)
  - `MaxSlicedWassersteinDistance` (MaxSWD)
  - `OrthogonalSlicedWassersteinDistance` (OSWD)
  - `GeneralisedSlicedWassersteinDistance` (GSWD)
  - `ProjectedWassersteinDistance` (PSWD)
- `BaseWD.forward()` handles batch dimension squeezing and calls `_validate_tensors` before delegating to `_forward()`

**`src/zreg/downsampling.py`** — Point Cloud Downsampling
- Purpose: Reduce point cloud size before expensive distance computations
- `farthest_point_down_sample()` — prefers `torch_cluster.fps` (GPU); falls back to Open3D `farthest_point_down_sample` (CPU)
- `random_down_sample()` — random index selection
- `uniform_down_sample()` — stride-based
- `remove_outliers_knn()` — KNN-based outlier removal
- `precompute_fps()` — stores FPS indices on the `zRegPointCloud` for reuse
- `TORCH_CLUSTER_AVAILABLE` flag set at import time via try/except

**`src/zreg/pairwise_distance_matrix.py`** — Cross-Trajectory Distance Computation
- Purpose: Fill an `(n_metrics, T_x, T_y)` distance matrix for two trajectory dicts
- Orchestrates: downsampling → optional CPD → distance metric calls
- Optional MPI distribution: `if "NOMPI" not in os.environ: from mpi4py import MPI` at module top
- Window support: Sakoe-Chiba band trims computation to `2*window+1` diagonals
- Returns `(distance_matrix: Tensor, rotations: Tensor)` tuple
- `create_pairwise_distance_matrix_given_rigid_rot()` — variant that reuses pre-computed CPD rotations

**`src/zreg/dtw.py`** — Dynamic Time Warping
- Purpose: Temporal alignment of two point cloud trajectories
- `DynamicTimeWarping` class wraps `create_pairwise_distance_matrix()` to produce a cost matrix, then runs windowed DP backtracking
- `DTWResult` dataclass carries: `cost_matrix`, `accumulated_cost`, `warping_path`, `distance`, `rotations`
- `.compute(metric_index)` runs the full pipeline; supports multi-metric cost matrices

**`src/zreg/color_transfer.py`** — Label Propagation
- Purpose: Assign cell-type/color labels from source to target after alignment
- `ColorTransferMethod` enum: `NEAREST_NEIGHBOR`, `CPD_WEIGHTED`, `KNN_VOTING`, `GAUSSIAN_KERNEL`
- `transfer_colors()` dispatches to the correct method based on enum value
- `CPD_WEIGHTED` requires an `EstepResult` from CPD's E-step (reuses posterior probabilities)

**`src/zreg/setup_log.py`** — Logging Infrastructure
- `setup_logger()` configures a `"zreg"` named logger with `colorlog` formatting
- Called once at package import in `src/zreg/__init__.py`
- Log level overridable via `ZREG_LOG_LEVEL` env var or `zreg.set_log_level()`

---

## Data Flow

**Point Cloud Registration (CPD):**

1. User calls `zreg.cpd.cpd_registration(source, target, tf_type_name="rigid")`
2. Open3D inputs converted to `zRegPointCloud` if needed
3. `RigidCPD` (or other subclass) instantiated with source
4. EM loop: `expectation_step()` → `_m_step()` alternating until convergence (tol on `q`)
5. Returns `MstepResult` with `.transformation` (a `RigidTransformation` object)
6. User calls `result.transformation.transform(source)` to apply

**Trajectory Distance Matrix:**

1. User provides two `Dict[int, zRegPointCloud]` trajectories
2. `create_pairwise_distance_matrix()` iterates time pairs (with optional window)
3. For each pair: normalize → downsample → optional CPD → compute distance metric(s)
4. Returns `(distance_matrix, rotations)` tensors

**DTW Alignment:**

1. `DynamicTimeWarping.compute()` calls `create_pairwise_distance_matrix()` to get cost matrix
2. DP fills `accumulated_cost` matrix with optional Sakoe-Chiba band
3. Backtrace yields `warping_path` as `List[Tuple[int, int]]`

**Color Transfer:**

1. Source and target point clouds provided (pre-aligned or to be aligned)
2. `transfer_colors()` extracts positions; dispatches to selected method
3. Returns `torch.Tensor` of transferred color labels

---

## Key Abstractions

**`zRegPointCloud` (`src/zreg/dataset.py`):**
- Purpose: Typed dict wrapping per-point tensor arrays; the universal data container
- Fields: `pos` (N,3), `color` (N,C), `id` (N,), `fps-idx` (N,)
- All fields are optional (default `None`); callers must check before use
- `.to(device)` enables device-transparent code

**`TransformBase` hierarchy (`src/zreg/transforms.py`):**
- Purpose: Unified `.transform(points)` interface across rigid/affine/non-rigid/TPS
- Pattern: template method — base handles extra feature columns; subclass implements `_transform()` on xyz only

**`CoherentPointDrift` + subclasses (`src/zreg/cpd.py`):**
- Pattern: Template method for EM — base provides E-step and loop; subclasses provide M-step
- `MstepResult` named tuple is the only inter-step data contract

**`BaseWD` (`src/zreg/distances/sw_varients.py`):**
- Extends `nn.Module`; subclasses implement `_forward()`
- Batch dimension normalization in `forward()` makes all SWD variants accept both 2D and 3D inputs

---

## Error Handling

**Strategy:** Fail fast at API boundaries; no silent fallbacks for data errors

**Patterns:**
- `_validate_tensors()` raises `ValueError` for NaN/inf or device mismatch — called at every module's public entry point
- `RigidTransformation.__mul__` validates determinant and condition number after composition (raises `ValueError`)
- `cpd_registration` raises `TypeError` for unsupported `tf_type_name`
- `transfer_colors` raises `ValueError` for missing required parameters
- GPU fallback for FPS is silent: `TORCH_CLUSTER_AVAILABLE` flag selects Open3D CPU path without raising

---

## Cross-Cutting Concerns

**Logging:** `logging.getLogger(__name__)` in every module under the `"zreg"` namespace hierarchy; configured once in `src/zreg/setup_log.py`

**Validation:** `_validate_tensors()` from `src/zreg/validation.py` — used in `cpd.py`, `distances/general.py`, `distances/sw_varients.py`, `pairwise_distance_matrix.py`, `color_transfer.py`

**Device Handling:** All tensors stay on whatever device the input is on; GPU-specific paths selected at runtime via `torch.cuda.is_available()` or explicit `device` args

**Optional Dependencies:** `torch_cluster` and `mpi4py` are soft dependencies — guarded by try/import and env-var checks respectively; graceful CPU fallbacks exist for both

---

*Architecture analysis: 2026-04-10*
