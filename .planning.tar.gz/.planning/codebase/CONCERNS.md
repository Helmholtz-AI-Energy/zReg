# Codebase Concerns

**Analysis Date:** 2026-04-10

## Executive Summary

zReg is a research-grade point cloud registration library with a solid core, but it carries several concrete risks: a hard-coded, dataset-specific rotation initialisation embedded in production CPD code, two live `print()` calls in a hot loop, and a `minkowski_distance` function that silently ignores its `p` parameter. Most remaining issues are well-contained tech debt items or missing features rather than correctness bugs.

---

## Known Bugs / Silent Correctness Errors

**`minkowski_distance` ignores the `p` parameter:**
- File: `src/zreg/distances/general.py`, line 81
- `torch.cdist(x, y, p=2)` is always called with `p=2`, regardless of what the caller passes. The old correct implementation is commented out below (lines 83-89).
- Impact: `manhattan_distance` and any `minkowski_distance` call with `p != 2` silently returns Euclidean distance instead.
- Fix: restore the commented-out dispatch block or pass the `p` argument through to `torch.cdist`.

**`normalize_point_cloud` range division can produce NaN for flat/degenerate inputs:**
- File: `src/zreg/utils.py`, line 214
- `ranges = max_vals - min_vals` can be zero (all-identical points along an axis), making `2 * (points - min_vals) / ranges` produce NaN or Inf without any guard.
- Impact: Silent NaN propagation into CPD and all distance metrics; `_validate_tensors` will only catch it after the fact.
- Fix: clamp `ranges` to a small epsilon before division, or raise early when a zero-range axis is detected.

---

## Tech Debt

**Hard-coded, dataset-specific rotation initialisation in `RigidCPD._initialize`:**
- File: `src/zreg/cpd.py`, lines 506-513
- A non-identity rotation matrix (`[[-0, -1, 0], [1, -0, 0.5], [0, 0.5, 1]]`) is baked in with the comment *"NOTE: this rotation matrix was found to work with for Shah data to Kobiski data! There is no other reason for this initialization!!!"*
- Impact: Any dataset with a different canonical orientation will converge more slowly or to a wrong local minimum.
- Fix: Default to identity and expose `tf_init_params` properly, or add a configurable `rot_init` argument.

**Mutable default argument on `RigidCPD` and `AffineCPD`:**
- File: `src/zreg/cpd.py`, lines 466 and 688
- `tf_init_params: Dict = {}` — the classic Python footgun. A shared dict is mutated via `.update(fact)` (line 480), so a second instantiation without explicit `tf_init_params` would inherit the previous call's state.
- Fix: Use `tf_init_params: Optional[Dict] = None` with `if tf_init_params is None: tf_init_params = {}`.

**`todo` comment for missing guard on color-mode CPD:**
- File: `src/zreg/cpd.py`, line 101
- `# todo: add raise if source colors not given` — when `use_color=True` but `source_colors=None`, the code silently stores `None` and will crash later with an unhelpful `AttributeError` (e.g., `NoneType has no attribute 'shape'`).
- Fix: Add an explicit `ValueError` at initialisation time.

**`normalize_to_pc_w_most_points` operates only on raw tensors, not `zRegPointCloud`:**
- File: `src/zreg/utils.py`, line 304
- `# TODO: fix normalize to use the points dicts not just the torch dicts`
- The commented-out alternative call in `pairwise_distance_matrix.py` (lines 167, 365) shows that the design intent was to normalise `zRegPointCloud` objects consistently, but the current per-field approach (`xi["pos"], _ = normalize_point_cloud(xi["pos"])`) leaves `color` and `id` fields unscaled.
- Fix: Add a `zRegPointCloud`-aware wrapper or extend `normalize_point_cloud` to accept `zRegPointCloud`.

**`farthest` downsampling ignores `points` kwargs from callers:**
- File: `src/zreg/pairwise_distance_matrix.py`, lines 575-577
- `# TODO: add partial for kwargs?` — the `farthest_point_down_sample` partial always passes `points=None`, so a caller cannot override the target point count through `distance_kwargs`.
- Fix: Thread kwargs through `partial()` or accept them at the sanitise step.

**`minkowski_distance` `normalize` kwarg cannot pass custom min/max:**
- File: `src/zreg/distances/general.py`, line 76
- `# TODO: add option to pass min/max to normalization function within this function` — callers that have already computed bounds cannot reuse them, leading to redundant computation.

**Voxel downsampling is not implemented:**
- File: `src/zreg/downsampling.py`, lines 457-467
- `# TODO: check out how to make this work in the future` — the entire `voxel_down_sample` function is commented out. Either implement or remove the dead comment block.

**`DeformableKinematicModel` transformation class is fully commented out:**
- File: `src/zreg/transforms.py`, lines 285-337
- The dependency on `dq3d` (dual quaternion) is removed but the commented skeleton remains, creating noise and false implied roadmap.

---

## Global Side-Effects / Module-Level State

**`torch.set_float32_matmul_precision("high")` called at import time:**
- File: `src/zreg/cpd.py`, line 27
- This silently changes a global PyTorch setting for the entire process whenever `cpd` is imported. Users embedding zReg in a larger system will have this applied without opt-in.
- Fix: Move to an explicit `configure()` call or document prominently.

**`torch.set_default_device(device)` called in `BaseWD.__init__`:**
- File: `src/zreg/distances/sw_varients.py`, line 129
- Calling `torch.set_default_device` inside a constructor changes the global default for all subsequent tensor allocations in the process — not just for this instance. Constructing two `BaseWD` instances with different devices is undefined or racy.
- Fix: Remove the global setter; pass `device=` explicitly to every `torch.*` call inside `_forward`.

---

## Performance Bottlenecks

**DTW accumulated cost computed in pure Python double loop:**
- File: `src/zreg/dtw.py`, lines 251-264
- `_compute_accumulated_cost` iterates `n × m` times in Python with `torch.stack` and `torch.min` per cell. For large trajectories this is the dominant cost.
- Fix: Implement the DP in a vectorised form or use a Cython/Numba kernel. The `window` (Sakoe-Chiba) constraint already limits cells, but the loop overhead remains.

**`deepcopy` of full point clouds per matrix cell:**
- File: `src/zreg/pairwise_distance_matrix.py`, lines 153-154 and 353-354
- Each `(i, j)` iteration calls `deepcopy(x[i])` and `deepcopy(y[j])`, which copies all torch tensors. For large point clouds this dominates wall time (the timing dict exposes this as the "copy" column).
- Fix: Use `.clone()` on only the tensors that get mutated, or pass read-only views with explicit `.clone()` at mutation sites.

**Open3D FPS requires CPU numpy round-trip even for GPU tensors:**
- File: `src/zreg/downsampling.py`, lines 52-65 (`_fps_open3d`)
- `.cpu().numpy()` → Open3D → cKDTree query → back to torch tensor. For GPU inputs this forces a device transfer before and after every FPS call.
- Fix: Ensure `torch_cluster` is available in the default environment so the auto-detect logic (`TORCH_CLUSTER_AVAILABLE and pos.is_cuda`) routes GPU tensors correctly.

---

## Fragile Areas

**`remove_outliers_knn` normalisation heuristic:**
- File: `src/zreg/downsampling.py`, line 472
- `if pos_base.max() > 5:` is an arbitrary threshold to decide whether to normalise before KNN. Point clouds whose coordinates happen to be in `(-5, 5)` will bypass normalisation even if they are not pre-normalised.
- Fix: Accept an explicit `already_normalized: bool` flag instead.

**`_preserve_labels` uses exact float equality for coordinate matching:**
- File: `src/zreg/downsampling.py`, lines 205-213
- Exact floating-point `==` between positions is used to find matching points after downsampling. Any FP rounding will cause missed matches and silently missing labels. This function appears unused in current tested code paths, but it is not guarded.

**`pairwise_distance_matrix` row-reset logic with `window=0`:**
- File: `src/zreg/pairwise_distance_matrix.py`, lines 232-251
- If a `window` setting results in a row with zero cells to compute, `len(times["copy"]) == 0` causes a silent `continue` at the row boundary, skipping MPI synchronisation for that row. MPI ranks can diverge silently.

**`AffineTransformation` default translation initialised to `torch.ones(3)`:**
- File: `src/zreg/transforms.py`, line 198
- Convention for a no-op affine is `t = zeros`. Initialising to `ones` means a default-constructed `AffineTransformation` is not an identity transform, which can surprise callers.

---

## Security Considerations

No web-facing surface, user-controlled file parsing over a network, or credential handling detected. `load_data_from_tracklets` (`src/zreg/dataset.py`, line 122) and `load_shah_from_csv` (line 285) accept caller-supplied file paths but operate on the local filesystem only. No concerns beyond standard file-path validation best practices.

---

## Test Coverage Gaps

**Color-mode CPD (`use_color=True`) path:**
- The `use_color` branch in `CoherentPointDrift.expectation_step` (`src/zreg/cpd.py`, lines 204-217) is exercised at a surface level, but the formula for `o_c` (the color-mixing denominator) has no dedicated numerical regression test. The silent `None` crash when `source_colors` is missing is also untested.

**`minkowski_distance` `p` parameter variations:**
- File: `tests/test_distances.py` — given the silent bug above (always `p=2`), tests likely do not distinguish `p=1` from `p=2`.

**`normalize_point_cloud` zero-range / degenerate axis:**
- No test covers a flat point cloud (all-same coordinate on one axis), which triggers NaN as described in the Known Bugs section.

**`_preserve_labels`:**
- File: `src/zreg/downsampling.py`, lines 205-213 — no test coverage found.

**`MaxSlicedWassersteinDistance`:**
- File: `src/zreg/distances/sw_varients.py` — exposed in `__all__` and `distances/__init__.py` but does not appear to be exercised in `tests/test_distances.py`.

**`AdaptiveSlicedWassersteinDistance.remove_history` race condition guard:**
- File: `src/zreg/distances/sw_varients.py`, line 258 — the `FileNotFoundError` branch is not exercised by any test.

---

## Deprecated / Dead Patterns

**Commented-out imports in `cpd.py`:**
- Lines 7-9 (`import six`, `from scipy.spatial import distance`, `from . import math_utils`) — vestiges of an older implementation. Should be removed.

**Commented-out `DistModule` class:**
- File: `src/zreg/cpd.py`, lines 49-54 — dead code that predates the current `torch.cdist` usage.

**Commented-out `@torch.compile` decorators:**
- File: `src/zreg/cpd.py`, lines 160, 227, 303 — three decorators tried and disabled. Status should be resolved: either remove or re-enable behind a feature flag.

**`print("end of first iteration")` in hot loop:**
- File: `src/zreg/pairwise_distance_matrix.py`, lines 229 and 414 — raw `print()` calls inside the inner distance-matrix loop bypass the logging framework and pollute stdout unconditionally.
- Fix: Replace with `log.debug(...)`.

**`print(log)` in `setup_log.py`:**
- File: `src/zreg/setup_log.py`, line 69 — a debug print left in the logging-setup utility; should be removed.

---

*Concerns audit: 2026-04-10*
