# Coding Conventions

**Analysis Date:** 2026-04-10

**Executive Summary:** zReg uses Ruff for both linting and formatting (Black-compatible, 120-char line limit, double quotes), enforced via pre-commit hooks. All public APIs carry NumPy-style docstrings with full `Parameters`, `Returns`, and `Raises` sections. Commit messages follow conventional commits format (`type(scope): description`).

---

## Linting and Formatting

**Tool:** Ruff (replaces Black + Flake8)
- Config: `pyproject.toml` `[tool.ruff]` and `[tool.ruff.lint]` sections
- Pre-commit hooks: `.pre-commit-config.yaml` (ruff v0.6.5, hooks: `ruff` and `ruff-format`)

**Key settings (`pyproject.toml`):**
- `line-length = 120`
- `indent-width = 4`
- `quote-style = "double"` (Black-compatible)
- `indent-style = "space"` (no tabs)
- `line-ending = "auto"`
- `skip-magic-trailing-comma = false`
- Enabled lint rules: `E4`, `E7`, `E9` (pycodestyle errors), `F` (Pyflakes)
- Per-file ignores: `**/__init__.py` ignores `F401` (unused imports), `E402` (module import order), `F403` (star imports)

**isort config** (`.isort.cfg`):
- `profile = black`
- `known_first_party = zreg`

**Pre-commit hooks** (`.pre-commit-config.yaml`):
- `ruff --fix` + `ruff-format` — lint and format on commit
- `trailing-whitespace` — strip trailing spaces
- `end-of-file-fixer` — enforce single trailing newline
- `check-ast` — validate Python syntax before commit
- `check-yaml`, `check-json`, `check-xml` — config file validity
- `check-merge-conflict` — reject stray merge markers
- `debug-statements` — reject committed `pdb`/`breakpoint()` calls
- `check-added-large-files` — prevent accidental binary commits
- `mixed-line-ending --fix=auto` — normalize line endings

Note: isort and Black hooks are present but commented out in `.pre-commit-config.yaml`; Ruff handles both roles.

---

## Docstring Style

**Format:** NumPy docstring style. Mandatory on all public functions, methods, and classes. Private functions (underscore-prefixed) may use inline comments only.

**Module-level docstrings** are present in all source modules. Format:
```
"""One-sentence summary of module purpose.

Extended description paragraph.
"""
```
Examples: `src/zreg/dtw.py`, `src/zreg/validation.py`, `src/zreg/color_transfer.py`.

**Function/method docstrings** use the full NumPy section format. Required sections for public API: `Parameters`, `Returns`, `Raises`. `Examples` and `Notes` added for complex functions.

**Example from `src/zreg/dtw.py`:**
```python
def compute(self, metric_index: int = 0) -> DTWResult:
    """Run the full DTW pipeline.

    Computes the cost matrix, accumulated cost matrix, and extracts
    the optimal warping path via backtracing.

    Parameters
    ----------
    metric_index : int, optional
        If multiple distance metrics are used, specify which one to use
        for the DTW path computation. Default: 0 (first metric).

    Returns
    -------
    DTWResult
        Container with cost matrix, accumulated cost, warping path, and distance.
    """
```

**Example from `src/zreg/validation.py`:**
```python
def _validate_tensors(
    *tensors: torch.Tensor,
    names: Sequence[str],
    check_finite: bool = True,
    check_device: bool = True,
) -> None:
    """Validate one or more tensors before computation.

    ...

    Raises
    ------
    ValueError
        If the number of tensors does not match the number of names.
        If any tensor contains NaN or inf values (when check_finite=True).
        If tensors reside on different devices (when check_device=True and len > 1).
    """
```

**Class docstrings** use `Parameters` (constructor args) and `Attributes` sections. `Examples` included for primary public classes (`DynamicTimeWarping` in `src/zreg/dtw.py`).

**Dataclass field docstrings** use the `Attributes` section on the class docstring. Fields in `DTWResult` (`src/zreg/dtw.py`) are all documented this way.

---

## Naming Patterns

**Files:**
- `snake_case.py` — all source modules (`color_transfer.py`, `pairwise_distance_matrix.py`, `sw_varients.py`)
- `test_<module_name>.py` — mirrors source module (`test_color_transfer.py`, `test_dtw.py`)
- `conftest.py` — shared pytest fixtures and hooks

**Classes:**
- `PascalCase` — `DynamicTimeWarping`, `RigidTransformation`, `ColorTransferMethod`, `DTWResult`
- Exception: `zRegPointCloud` — internal brand prefix `zReg` preserved (not fully PascalCase). Defined in `src/zreg/dataset.py`.

**Functions and methods:**
- `snake_case` — `compute_cost_matrix`, `transfer_colors`, `get_aligned_trajectory`
- Private / internal: single underscore prefix — `_compute_accumulated_cost`, `_backtrace`, `_validate_tensors`
- Helper math functions: short descriptive names — `rbf_kernel`, `tps_kernel`, `squared_kernel`

**Variables and parameters:**
- `snake_case` for all parameters and locals
- Single-letter loop variables acceptable in tight math: `i`, `j`, `n`, `m`, `d`
- `x`, `y` used for paired inputs (trajectories, point clouds) throughout the codebase
- Boolean flags named descriptively: `normalize`, `mpi_distribute`, `return_o3d`, `check_finite`

**Module-level logger:**
- Always bound to `log` (not `logger`): `log = logging.getLogger(__name__)`
- Present in: `src/zreg/dtw.py`, `src/zreg/dataset.py`, `src/zreg/color_transfer.py`, `src/zreg/cpd.py`, `src/zreg/pairwise_distance_matrix.py`, `src/zreg/downsampling.py`

**Module exports:**
- Every source module defines `__all__` explicitly
- Only public names included; private helpers omitted
- Example from `src/zreg/dtw.py`: `__all__ = ["DynamicTimeWarping", "DTWResult"]`

---

## Type Annotations

All public function signatures carry full type annotations using `typing` module types (not Python 3.10+ union syntax `X | Y`):

```python
from typing import Dict, List, Optional, Tuple, Union

def __init__(
    self,
    x: Dict[int, zRegPointCloud],
    y: Dict[int, zRegPointCloud],
    distance_metric: Union[List[str], str] = "swd",
    distance_kwargs: Optional[Union[List[Dict], Dict]] = None,
    window: Optional[int] = None,
    normalize: bool = True,
) -> None:
```

Return type annotation always present on public methods. Private methods (`_compute_accumulated_cost`, `_backtrace`) also carry annotations.

`dataclass` fields annotated directly: `cost_matrix: torch.Tensor`, `rotations: Optional[torch.Tensor] = None`.

---

## Import Organization

Enforced by isort (Black profile). Standard order:

1. **Standard library:** `from dataclasses import dataclass`, `from pathlib import Path`, `import logging`, `from typing import ...`
2. **Third-party:** `import torch`, `import open3d as o3d`, `import open3d.t.geometry as o3dtgeo`
3. **Internal (relative):** `from .dataset import zRegPointCloud`, `from . import utils`, `from .pairwise_distance_matrix import create_pairwise_distance_matrix`

Tests use absolute imports: `from zreg.dtw import DynamicTimeWarping`, `from zreg.dataset import zRegPointCloud`.

Common aliases: `o3d` for `open3d`, `o3dtgeo` for `open3d.t.geometry`, `o3c` for `open3d.core`.

---

## Error Handling

**ValueError** — domain or input errors (invalid argument values, shape mismatches, NaN/inf data):
```python
raise ValueError(
    f"DTW warping path could not be traced — window too tight or "
    f"disconnected cost matrix. "
    f"Dead-end at ({i}, {j}), predecessor costs: {predecessor_values}"
)
```

**RuntimeError** — state errors (calling method before required setup):
```python
if self.result is None:
    raise RuntimeError("DTW has not been computed yet. Call compute() first.")
```

**TypeError** — type mismatch on input:
```python
raise TypeError("points given are torch tensor, pass whole Dict or the o3d PointCloud class!")
```

Error messages always include: the offending value or position, what was expected, and an actionable hint. F-strings with embedded values are standard in error messages.

`try/except AttributeError` used sparingly for duck-typing fallbacks (e.g., `.numpy()` call in `src/zreg/transforms.py`).

---

## Logging

**Framework:** Python `logging` module; `colorlog` package provides colored console output (configured in `src/zreg/setup_log.py`).

**Pattern:**
- `log.info(f"...")` — pipeline progress milestones, completion summaries
- `log.warning(...)` — non-fatal issues (e.g., optional dependency missing)
- F-strings with relevant metrics in log messages: `log.info(f"DTW computation complete. Distance: {distance:.4f}, Path length: {len(warping_path)}")`

Optional imports (e.g., matplotlib) are guarded and fall back to a `log.warning()`:
```python
try:
    import matplotlib.pyplot as plt
except ImportError:
    log.warning("matplotlib not available. Cannot create plot.")
    return
```

---

## Comments

**Algorithm step labels:** Multi-step algorithms annotated with `# Step N: description`:
```python
# Step 1: Compute pairwise cost matrix
cost_matrix = self.compute_cost_matrix()
# Step 2: Compute accumulated cost matrix
accumulated_cost = self._compute_accumulated_cost(cost_for_dtw)
```

**Attribution:** Source inspiration credited at module top: `# This file takes insperation from https://github.com/neka-nat/probreg/` (`src/zreg/transforms.py`).

**TODO format:** `# TODO: <description>`. Active TODOs in:
- `src/zreg/distances/general.py:76` — add min/max passthrough to normalization
- `src/zreg/downsampling.py:457` — future work on a downsampling approach
- `src/zreg/pairwise_distance_matrix.py:575` — add partial for kwargs
- `src/zreg/transforms.py:285` — adapt commented-out `DeformableKinematicModel` for torch
- `src/zreg/utils.py:304` — fix normalize to use point cloud dicts

**Dead code:** Large disabled blocks retained as comments with explanatory context (e.g., `DeformableKinematicModel` in `src/zreg/transforms.py`).

---

## Module Design

**Dataclasses:** Used for result containers. `DTWResult` in `src/zreg/dtw.py` is a `@dataclass` with typed fields and `Optional` defaults.

**Enums:** `enum.Enum` for strategy/method choices. `ColorTransferMethod` in `src/zreg/color_transfer.py` enumerates the four transfer methods.

**Inheritance:** `TransformBase` → `RigidTransformation`, `AffineTransformation`, `NonRigidTransformation`, `CombinedTransformation`, `TPSTransformation` in `src/zreg/transforms.py`. Base provides `transform()` dispatch; subclasses implement `_transform()`.

**Classmethod constructors:** Used for alternate construction and deserialization. `DynamicTimeWarping.load()` in `src/zreg/dtw.py` is a `@classmethod` returning a `DTWResult`.

**Barrel files:** `src/zreg/__init__.py` imports and re-exports submodules. `src/zreg/distances/__init__.py` aggregates the distances subpackage.

---

## Commit and Contribution Conventions

**Commit message format:** Conventional commits — `type(scope): description`. Types observed in recent git log:
- `feat` — new feature
- `fix` — bug fix
- `test` — adding or updating tests
- `docs` — documentation changes
- `chore` — housekeeping
- `refactor` — code restructuring

Examples from git log:
```
feat(05-03): add empty-source guard to transfer_colors and edge case tests
test(05-02): add DTW metric variants, windowed asymmetric, and boundary condition tests
docs: rewrite README with accurate project description for v1.0
```

**Branching:** Feature branches off main. Branch names observed: `refactor/general`.

**Pre-commit required:** Hooks must pass before commit. `CONTRIBUTING.md` specifies `pre-commit install` as a setup step.

**New public API requirements** (per `CONTRIBUTING.md`): docstrings required, unit tests required, `AUTHORS.rst` entry recommended.

**Release process:** Tag-based (`v1.2.3` on main), published via `tox -e publish`.

---

*Convention analysis: 2026-04-10*
