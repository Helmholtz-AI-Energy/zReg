# External Integrations

**Analysis Date:** 2026-04-10

## Executive Summary

zReg is a self-contained scientific computing library with no active integrations to remote APIs, cloud services, or external databases. All data I/O is local-filesystem-based (MATLAB `.mat`, CSV, and Open3D-supported point cloud formats). The only external systems in use are Read the Docs for documentation hosting and SLURM-managed HPC infrastructure for compute.

---

## APIs & External Services

**None detected.** zReg does not call any remote HTTP APIs. There are no HTTP client libraries (e.g., `requests`, `httpx`) in `install_requires` or `environment.yml`.

---

## Data Storage

**Databases:**
- Not applicable. No ORM, database driver, or persistent database layer is present.

**File Storage — Local Filesystem Only:**
- MATLAB files (`.mat`) — loaded via `scipy.io.loadmat` in `src/zreg/dataset.py` (`load_data_from_tracklets`)
- CSV files — read via Python built-in `csv` module in `src/zreg/dataset.py` (`load_shah_from_csv`)
- Open3D-supported formats (`.ply`, `.pcd`, etc.) — accessed via `open3d.t.geometry.PointCloud` in `src/zreg/dataset.py` (`open3d_to_zreg`, `zreg_to_open3d`)
- PyTorch tensors — in-memory; no serialization to disk detected in core library (notebooks/scripts may write `.pt` files)

**Caching:**
- None. No Redis, Memcached, or disk-cache library is used.

---

## Authentication & Identity

**Auth Provider:**
- Not applicable. No authentication system is integrated.

---

## Monitoring & Observability

**Error Tracking:**
- None. No Sentry, Rollbar, or similar service is configured.

**Logs:**
- Local stdout/file logging via Python `logging` + `colorlog`
- Configured in `src/zreg/setup_log.py`; initialized in `src/zreg/__init__.py`
- Log level controlled by `ZREG_LOG_LEVEL` environment variable (default `INFO`)
- Optional file handler: pass `log_file` path to `setup_logger()` in `src/zreg/setup_log.py`
- No remote log aggregation (no ELK, Datadog, CloudWatch, etc.)

---

## CI/CD & Deployment

**Hosting:**
- Library package — not deployed as a service
- Docker image: `condaforge/mambaforge`-based multi-stage build (`Dockerfile`); no registry push target configured

**CI Pipeline:**
- No GitHub Actions, GitLab CI, CircleCI, or similar CI configuration detected
- Local automation only: `tox.ini` (pytest, build, docs, publish environments), `pre-commit` hooks

**Documentation Publishing:**
- Read the Docs (`.readthedocs.yml`): triggered on git push; builds Sphinx docs at `docs/conf.py`; Python 3.11 on ubuntu-22.04; outputs HTML + PDF

**Package Publishing:**
- PyPI via `tox -e publish` (uses `twine`); repository defaults to `testpypi` unless `TWINE_REPOSITORY` env var overrides it (`tox.ini`)

---

## HPC Integration

**Cluster:**
- SLURM workload manager — job scripts in `scripts/launch.sbatch` and `scripts/launch_srun.sh`
- Target partition: `booster`; account: `tissuetwin`; 3 nodes × 4 GPUs per node
- MPI backend: pspmix (`--mpi=pspmix`) via `mpi4py`; distributed pairwise distance matrix computation in `src/zreg/pairwise_distance_matrix.py`
- Project paths on cluster: `/p/project/tissuetwin/coquelin1/zReg/` and `/p/project1/tissuetwin/coquelin1/`

---

## Environment Configuration

**Required environment variables:**
- None required for basic operation

**Optional environment variables:**
- `ZREG_LOG_LEVEL` — logging verbosity (e.g., `DEBUG`, `WARNING`)
- `NOMPI` — disable MPI import in `src/zreg/pairwise_distance_matrix.py` when running without MPI support
- `TWINE_USERNAME`, `TWINE_PASSWORD`, `TWINE_REPOSITORY`, `TWINE_REPOSITORY_URL` — for `tox -e publish`

**Secrets:**
- No secrets management system. No `.env` file detected.

---

## Webhooks & Callbacks

**Incoming:** None.
**Outgoing:** None.

---

## Third-Party Algorithm Attributions

The following upstream open-source projects are adapted (not called as services) within the codebase:

- **probreg** (`https://github.com/neka-nat/probreg`) — CPD algorithm inspiration; reimplemented with PyTorch in `src/zreg/cpd.py` and `src/zreg/transforms.py`
- **PointSWD** (`https://github.com/VinAIResearch/PointSWD`) — Sliced Wasserstein Distance variants; adapted in `src/zreg/distances/sw_varients.py`

---

*Integration audit: 2026-04-10*
