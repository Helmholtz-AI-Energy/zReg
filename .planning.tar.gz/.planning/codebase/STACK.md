# Technology Stack

**Analysis Date:** 2026-04-10

## Executive Summary

zReg is a Python scientific computing library for 3D point cloud registration, temporal alignment, and color transfer, scaffolded with PyScaffold 4.6. It is built on PyTorch for tensor operations and GPU acceleration, Open3D for point cloud geometry, and SciPy for spatial data structures. The package targets Python 3.9–3.12 and is structured as an installable namespace package under `src/zreg`.

---

## Languages

**Primary:**
- Python 3.9–3.12 (required range per `setup.cfg`; `.venv` uses Python 3.11.0 at `/usr/bin/python3.11`)

**Secondary:**
- None

---

## Runtime

**Environment:**
- CPython 3.11.0 (`.venv/pyvenv.cfg`)
- Supports CPU and CUDA GPU execution via PyTorch device abstraction

**Package Manager:**
- pip (primary for library install; `setup.cfg`, `pyproject.toml`)
- conda/mamba (alternative environment management via `environment.yml`; used in `Dockerfile`)
- Lockfile: not present — neither `requirements.txt` nor a pinned conda lock file is committed

---

## Frameworks

**Core Scientific Computing:**
- PyTorch (unpinned) — all tensor math, device management, autograd; used throughout `src/zreg/`
- Open3D (unpinned) — point cloud geometry, farthest-point sampling, tensor I/O; both standard API (`open3d`) and tensor API (`open3d.t.geometry`, `open3d.core`) used in `src/zreg/dataset.py`, `src/zreg/downsampling.py`, `src/zreg/transforms.py`, `src/zreg/cpd.py`
- SciPy (unpinned) — `scipy.spatial.cKDTree` for KNN queries in `src/zreg/downsampling.py`; `scipy.io` for MATLAB `.mat` file loading in `src/zreg/dataset.py`
- NumPy (unpinned) — array interop; declared in `setup.cfg` `install_requires`

**Testing:**
- pytest (unpinned) — test runner; config in `setup.cfg` `[tool:pytest]`; test root `tests/`
- pytest-cov — coverage; branch mode; config in `.coveragerc`

**Build/Dev:**
- setuptools >= 46.1.0 with setuptools_scm >= 5 — version derived from git tags, scheme `no-guess-dev` (`pyproject.toml`)
- tox >= 3.24 — environments: `default` (pytest), `build`, `clean`, `docs`, `doctests`, `linkcheck`, `publish` (`tox.ini`)
- ruff v0.6.5 — linting (rules E4, E7, E9, F) and formatting (double quotes, 120-char line length) (`pyproject.toml`, `.pre-commit-config.yaml`)
- pre-commit v5.0.0 — hooks: trailing whitespace, large files, AST validation, JSON/XML/YAML checks, merge-conflict detection, EOF fixer, line-ending normalizer (`.pre-commit-config.yaml`)
- Sphinx >= 3.2.1 with myst-parser — documentation (`docs/requirements.txt`, `.readthedocs.yml`)
- twine — PyPI publishing via `tox -e publish` (`tox.ini`)

---

## Key Dependencies

**Critical (declared in `setup.cfg` `install_requires`):**
- `numpy` — array operations foundation
- `scipy` — KDTree spatial queries, MATLAB `.mat` file I/O
- `torch` — all tensor math, GPU device management, autograd
- `open3d` — point cloud data structures and geometry algorithms
- `colorlog` — colored console logging (`src/zreg/setup_log.py`)
- `tqdm` — progress bars for long-running batch operations

**Optional extras (`setup.cfg` `[options.extras_require]`):**
- `mpi4py` — MPI distributed computation (`[mpi]` extra); conditionally imported in `src/zreg/pairwise_distance_matrix.py` when `NOMPI` env var is absent
- `matplotlib`, `seaborn` — visualization (`[viz]` extra); used in `scripts/` and `notebooks/`
- `torch_cluster` — GPU-accelerated farthest-point sampling; NOT declared in `setup.cfg`; must be installed manually from `https://data.pyg.org/whl/torch-X.X.X+cuXXX.html`; optional import with CPU fallback via Open3D in `src/zreg/downsampling.py`
- `pytest`, `pytest-cov`, `setuptools` — `[testing]` extra

**Dev/notebook extras (in `environment.yml` only, not installable via pip extras):**
- `pandas`, `click`, `ipython`, `jupyterlab`, `nbdime`, `nbstripout`, `ipympl`, `pyometiff`

---

## Configuration

**Environment variables:**
- `ZREG_LOG_LEVEL` — controls logging verbosity; read in `src/zreg/__init__.py`; defaults to `"INFO"`
- `NOMPI` — if set, skips `mpi4py` import in `src/zreg/pairwise_distance_matrix.py`
- No `.env` file detected

**Build configuration files:**
- `pyproject.toml` — build system (setuptools + setuptools_scm), ruff lint/format settings
- `setup.cfg` — package metadata, `install_requires`, extras, pytest config, flake8 config, pyscaffold metadata
- `setup.py` — minimal backward-compatibility shim
- `tox.ini` — tox environments for test, build, docs, publish
- `.coveragerc` — branch coverage, `source = zreg`, standard exclusion patterns
- `.isort.cfg` — import sorting with black profile, first-party: `zreg`
- `.pre-commit-config.yaml` — git hook configuration

---

## Platform Requirements

**Development:**
- Python 3.9–3.12
- pip or conda/mamba for environment management
- Optional: CUDA-capable GPU + matching `torch` wheel + manual `torch_cluster` wheel for GPU acceleration

**Production / Containerized:**
- Docker: multi-stage build using `condaforge/mambaforge` base image (`Dockerfile`); builder compiles wheel, runner installs it; runs as unprivileged user UID 1001

**HPC Cluster:**
- SLURM job scripts in `scripts/launch.sbatch` targeting partition `booster`, 3 nodes × 4 GPUs, MPI via pspmix; project account `tissuetwin`; scripts activate a venv at `/p/project1/tissuetwin/coquelin1/regvenv311/`

**Documentation Hosting:**
- Read the Docs (`.readthedocs.yml`): Python 3.11 on ubuntu-22.04, Sphinx, outputs HTML + PDF

---

*Stack analysis: 2026-04-10*
