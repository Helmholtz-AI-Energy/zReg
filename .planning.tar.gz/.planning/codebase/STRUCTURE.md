# Codebase Structure

**Analysis Date:** 2026-04-10

## Executive Summary

zReg follows a PyScaffold `dsproject` layout: source lives under `src/zreg/`, tests are in a top-level `tests/` directory, and supporting directories (`data/`, `models/`, `notebooks/`, `scripts/`, `configs/`) are data-science workspace folders. The importable package is `zreg` (lowercase); the PyPI name is `zReg` (mixed case). There is one subpackage: `zreg/distances/`.

---

## Directory Layout

```
zReg/                           # Project root
├── src/
│   └── zreg/                   # Installable package (src layout)
│       ├── __init__.py         # Package entry point, logging init, public re-exports
│       ├── dataset.py          # zRegPointCloud data model + I/O loaders
│       ├── validation.py       # _validate_tensors() — cross-cutting input guard
│       ├── utils.py            # Kernel functions, normalization math
│       ├── transforms.py       # TransformBase hierarchy (Rigid, Affine, NonRigid, TPS, Combined)
│       ├── cpd.py              # Coherent Point Drift (EM registration) — 1,263 lines
│       ├── downsampling.py     # FPS, random, uniform downsampling
│       ├── pairwise_distance_matrix.py  # Trajectory × Trajectory distance matrix
│       ├── dtw.py              # DynamicTimeWarping class + DTWResult dataclass
│       ├── color_transfer.py   # transfer_colors() + ColorTransferMethod enum
│       ├── setup_log.py        # setup_logger() with colorlog
│       └── distances/          # Distance metrics subpackage
│           ├── __init__.py     # Re-exports everything from sw_varients + general
│           ├── general.py      # euclidean, manhattan, minkowski distances
│           └── sw_varients.py  # 6 Sliced Wasserstein variants (nn.Module subclasses)
├── tests/
│   ├── conftest.py             # Shared fixtures (device, sample_points_3d, trajectory_data, ...)
│   ├── test_cpd.py
│   ├── test_transforms.py
│   ├── test_distances.py
│   ├── test_dtw.py
│   ├── test_pairwise_distance_matrix.py
│   ├── test_color_transfer.py
│   ├── test_downsampling.py
│   ├── test_dataset.py
│   ├── test_utils.py
│   └── test_validation.py
├── scripts/                    # Standalone analysis/demo scripts (not part of package)
│   ├── example_plots.py
│   ├── dtw_testing.py
│   ├── color_transfer_example.py
│   ├── train_model.py
│   ├── launch.sbatch           # SLURM job script
│   └── launch_srun.sh
├── notebooks/
│   ├── basics.ipynb
│   ├── cpd.ipynb
│   └── debug.ipynb
├── data/
│   ├── raw/                    # Original immutable data
│   ├── interim/                # Intermediate transformations
│   ├── processed/              # Final canonical datasets
│   └── external/               # Third-party data
├── configs/                    # Model/application YAML configs (currently empty)
├── models/                     # Saved model artifacts (currently empty)
├── docs/                       # Sphinx documentation source
│   └── _static/
├── reports/
│   └── figures/
├── references/                 # Papers, external references
├── .planning/                  # GSD planning artifacts (not part of package)
│   ├── codebase/               # Codebase map documents
│   ├── milestones/             # Milestone phase plans
│   └── phases/
├── setup.cfg                   # Declarative package metadata + pytest config + flake8
├── setup.py                    # Minimal shim for editable installs
├── pyproject.toml              # Build system config (setuptools)
├── environment.yml             # Conda environment definition
├── tox.ini                     # Tox test environments
├── .coveragerc                 # Coverage measurement config
├── .pre-commit-config.yaml     # Pre-commit hooks (black, isort, flake8)
├── .isort.cfg                  # isort configuration
├── Dockerfile                  # Container definition
└── README.md
```

---

## Directory Purposes

**`src/zreg/`:**
- Purpose: The entire installable library; everything users `import`
- Contains: All Python modules; one subpackage (`distances/`)
- Key files: `__init__.py` (wires up logging, re-exports all modules), `cpd.py` (largest at 1,263 lines), `pairwise_distance_matrix.py` (581 lines), `dtw.py` (605 lines)
- Installed via `pip install -e .` (editable) into the active env

**`src/zreg/distances/`:**
- Purpose: Distance metric implementations as a subpackage
- The `__init__.py` is a two-line star-import aggregator; all symbols land in `zreg.distances` namespace

**`tests/`:**
- Purpose: Pytest regression suite (275 tests at v1.0)
- Structure: One test file per source module (1:1 mapping)
- Shared fixtures in `tests/conftest.py`; no subdirectories

**`scripts/`:**
- Purpose: Developer/research scripts for exploration, demos, and HPC job submission
- Not importable as part of the package; not covered by tests
- SLURM scripts (`launch.sbatch`, `launch_srun.sh`) support MPI-distributed runs

**`data/`:**
- Purpose: Data science workspace; segregated by processing stage
- `data/raw/` — never modified; original MATLAB/CSV files
- `data/interim/` — intermediate results
- `data/processed/` — analysis-ready datasets

**`configs/`:**
- Purpose: Configuration files for model runs; currently unused

**`.planning/`:**
- Purpose: GSD planning system artifacts; not part of the library
- `codebase/` — codebase map documents (this file)
- `milestones/` — per-milestone phase plans and execution logs

---

## Key File Locations

**Package Entry Point:**
- `src/zreg/__init__.py` — imports all modules; sets up logging; exposes `set_log_level()` and `__version__`

**Package Configuration:**
- `setup.cfg` — authoritative: package name, Python version constraint (3.9–3.12), all dependencies, pytest addopts, flake8 config
- `pyproject.toml` — build system declaration only (`setuptools`)
- `setup.py` — minimal shim; do not add logic here
- `environment.yml` — conda environment pinning (includes editable install)
- `tox.ini` — tox test matrix configuration
- `.coveragerc` — coverage source and omit patterns

**Core Logic:**
- `src/zreg/cpd.py` — CPD registration (EM algorithm + 4 concrete classes)
- `src/zreg/pairwise_distance_matrix.py` — trajectory distance orchestration
- `src/zreg/dtw.py` — DTW wrapper and DP backtracing
- `src/zreg/distances/sw_varients.py` — all Sliced Wasserstein implementations
- `src/zreg/transforms.py` — transformation objects

**Data Model:**
- `src/zreg/dataset.py` — `zRegPointCloud`, loaders, Open3D converters

**Validation:**
- `src/zreg/validation.py` — `_validate_tensors()` (single function, 70 lines)

**Tests:**
- `tests/conftest.py` — shared fixtures
- `tests/test_*.py` — one file per module

---

## Naming Conventions

**Files:**
- Source modules: `snake_case.py` (e.g., `color_transfer.py`, `pairwise_distance_matrix.py`)
- Exception: `sw_varients.py` (typo; keep for backward compatibility)
- Test files: `test_{module_name}.py` (e.g., `test_color_transfer.py`)

**Directories:**
- Package: `zreg` (all lowercase, matches importable name)
- PyPI name: `zReg` (mixed case, used in `setup.cfg` and egg-info)
- Data dirs: `snake_case` (`raw`, `interim`, `processed`, `external`)

**Classes:**
- Public algorithm classes: `PascalCase` (e.g., `RigidCPD`, `DynamicTimeWarping`, `SlicedWassersteinDistance`)
- Data containers: `PascalCase` (e.g., `zRegPointCloud` — historical exception with leading lowercase)
- Enums: `PascalCase` (e.g., `ColorTransferMethod`)
- Named tuples: `PascalCase` (e.g., `EstepResult`, `MstepResult`)
- Dataclasses: `PascalCase` (e.g., `DTWResult`)

**Functions:**
- Public: `snake_case` (e.g., `cpd_registration`, `transfer_colors`, `create_pairwise_distance_matrix`)
- Private/internal: `_snake_case` (e.g., `_validate_tensors`, `_fps_open3d`, `_sanitize_pairwise_distance_matrix`)

**Constants:**
- `UPPER_SNAKE_CASE` (e.g., `TORCH_CLUSTER_AVAILABLE`)

---

## Where to Add New Code

**New distance metric:**
- Add implementation to `src/zreg/distances/sw_varients.py` (if SWD-family) or `src/zreg/distances/general.py` (if classical)
- Add to `__all__` in the respective file; it is automatically re-exported via `src/zreg/distances/__init__.py`
- Add string key dispatch in `src/zreg/pairwise_distance_matrix.py::_sanitize_pairwise_distance_matrix()`
- Add tests in `tests/test_distances.py`

**New transformation type:**
- Add class extending `TransformBase` in `src/zreg/transforms.py`
- Add to `__all__`
- Add corresponding CPD subclass in `src/zreg/cpd.py` if registration support is needed
- Add tests in `tests/test_transforms.py`

**New color transfer method:**
- Add value to `ColorTransferMethod` enum in `src/zreg/color_transfer.py`
- Add dispatch branch in `transfer_colors()`
- Add tests in `tests/test_color_transfer.py`

**New I/O format:**
- Add loader function to `src/zreg/dataset.py`; return `Dict[int, zRegPointCloud]`
- Add to `__all__` in `dataset.py`
- Add tests in `tests/test_dataset.py`

**New module (entirely new capability):**
- Add `src/zreg/{module_name}.py`
- Add `from . import {module_name} as {module_name}` to `src/zreg/__init__.py`
- Add `tests/test_{module_name}.py`
- Add shared fixtures (if needed) to `tests/conftest.py`

**Utilities used across modules:**
- Add to `src/zreg/utils.py` and `__all__`

---

## Special Directories

**`src/zReg.egg-info/`:**
- Purpose: Editable install metadata generated by setuptools
- Generated: Yes (do not commit; in `.gitignore`)
- Committed: No

**`src/zreg/__pycache__/` and `tests/__pycache__/`:**
- Generated: Yes
- Committed: No

**`.planning/`:**
- Purpose: GSD planning system — non-code artifacts
- Generated: Partially (maps are written by agents)
- Committed: Yes (tracked in git)

**`.pytest_cache/`:**
- Generated: Yes
- Committed: No

**`.venv/`:**
- Purpose: Local virtual environment
- Generated: Yes
- Committed: No (in `.gitignore`)

---

*Structure analysis: 2026-04-10*
