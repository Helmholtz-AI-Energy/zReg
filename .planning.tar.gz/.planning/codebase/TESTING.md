# Testing Patterns

**Analysis Date:** 2026-04-10

**Executive Summary:** zReg uses pytest with pytest-cov for all testing. 278 test functions across 10 test files (one per source module) are organized into `class Test*` suites. Tests are exclusively unit and integration level — no E2E tests. Coverage is measured via `--cov zreg --cov-report term-missing` on every run but no minimum threshold is enforced.

---

## Test Framework

**Runner:** pytest
- Config: `setup.cfg` `[tool:pytest]` section
- Test discovery path: `tests/` (configured via `testpaths = tests`)

**Assertion Library:**
- Native pytest `assert` statements
- `torch.allclose(a, b, atol=1e-5)` for floating-point tensor comparisons
- `torch.equal(a, b)` for exact tensor equality

**Run Commands:**
```bash
pytest                                    # Run all tests (uses setup.cfg defaults)
pytest --verbose                          # Already default via addopts in setup.cfg
pytest tests/test_dtw.py                  # Run single test file
pytest tests/test_dtw.py::TestDTWCompute # Run single test class
pytest tests/test_dtw.py::TestDTWCompute::test_compute_euclidean  # Run single test
pytest -m "not slow"                      # Skip tests marked slow
tox                                       # Full isolated test run via tox
```

**Coverage:**
```bash
pytest                        # Coverage always on: --cov zreg --cov-report term-missing
pytest --cov-report html      # Generate HTML coverage report
```

Coverage config in `.coveragerc`:
- `branch = True` (branch coverage enabled)
- `source = zreg`
- Excludes: `raise AssertionError`, `raise NotImplementedError`, `if __name__ == "__main__":`, `pragma: no cover`, `def __repr__`

**Tox:** `tox.ini` defines a `default` environment that runs `pytest {posargs}` with `testing` extras (pytest + pytest-cov + setuptools).

---

## Test File Organization

**Location:** `tests/` directory at project root, separate from source in `src/zreg/`.

**Naming:** One test file per source module, mirroring module names:

| Test File | Source Module |
|---|---|
| `tests/test_dtw.py` (759 lines, 42 tests) | `src/zreg/dtw.py` |
| `tests/test_cpd.py` (628 lines, 41 tests) | `src/zreg/cpd.py` |
| `tests/test_distances.py` (454 lines, 40 tests) | `src/zreg/distances/` |
| `tests/test_transforms.py` (379 lines, 32 tests) | `src/zreg/transforms.py` |
| `tests/test_pairwise_distance_matrix.py` (355 lines, 20 tests) | `src/zreg/pairwise_distance_matrix.py` |
| `tests/test_color_transfer.py` (342 lines, 19 tests) | `src/zreg/color_transfer.py` |
| `tests/test_downsampling.py` (285 lines, 22 tests) | `src/zreg/downsampling.py` |
| `tests/test_utils.py` (270 lines, 30 tests) | `src/zreg/utils.py` |
| `tests/test_validation.py` (182 lines, 18 tests) | `src/zreg/validation.py` |
| `tests/test_dataset.py` (202 lines, 14 tests) | `src/zreg/dataset.py` |
| `tests/conftest.py` | Shared fixtures |

**Total:** 278 test functions across 10 files, 3,856 lines.

---

## Test Structure

**Suite organization:** Tests grouped into `class Test*` suites per logical unit within each file. Each class has a docstring stating what it tests.

```python
class TestDTWCompute:
    """Tests for full DTW computation."""

    def test_compute_euclidean(self, small_trajectory_pair):
        """Test full DTW computation with Euclidean distance."""
        x, y = small_trajectory_pair
        dtw_obj = DynamicTimeWarping(
            x, y,
            distance_metric="euclidean",
            downsample_method=None,
            normalize=True,
        )
        result = dtw_obj.compute()

        assert isinstance(result, DTWResult)
        assert result.cost_matrix is not None
        assert result.distance >= 0
```

**Classes per file (examples from `tests/test_cpd.py`):**
- `TestCoherentPointDriftBase`, `TestEstepResult`, `TestMstepResult`, `TestRigidCPD`, `TestAffineCPD`, `TestNonRigidCPD`, `TestConstrainedNonRigidCPD`, `TestCPDRegistrationFunction`, `TestInitCPDFromExisting`, `TestCPDWithColor`, `TestRigidCPDScale`, `TestMstepResultDiagnostics`, `TestCPDNumericalStability`, `TestCPDDeviceHandling`

**Test method docstrings:** Every test method has a one-line docstring describing what is tested.

**Teardown:** No explicit teardown. File I/O tests use `tempfile.TemporaryDirectory()` as a context manager for automatic cleanup:
```python
with tempfile.TemporaryDirectory() as tmpdir:
    path = Path(tmpdir) / "dtw_result.pt"
    dtw_obj.save(path)
    assert path.exists()
    loaded_result = DynamicTimeWarping.load(path)
```

---

## Fixtures

**Global fixtures** in `tests/conftest.py`:

```python
@pytest.fixture
def device():
    """Return the device to use for tests."""
    return "cuda" if torch.cuda.is_available() else "cpu"

@pytest.fixture
def sample_points_3d():
    """Create sample 3D points."""
    return torch.randn(50, 3)

@pytest.fixture
def sample_pointcloud():
    """Create a sample zRegPointCloud."""
    return zRegPointCloud(
        pos=torch.randn(100, 3),
        color=torch.randn(100, 3),
        id=torch.arange(100),
    )

@pytest.fixture
def point_cloud_pair():
    """Create a pair of point clouds for registration testing."""
    source = torch.randn(50, 3)
    rotation = torch.tensor([
        [0.866, -0.5, 0.0],
        [0.5, 0.866, 0.0],
        [0.0, 0.0, 1.0],
    ])
    translation = torch.tensor([1.0, 2.0, 0.0])
    target = source @ rotation.T + translation
    return source, target

@pytest.fixture
def trajectory_data():
    """Create sample trajectory data (dict of time points to point clouds)."""
    trajectory = {}
    for t in range(5):
        trajectory[t] = zRegPointCloud(
            pos=torch.randn(30, 3) + t * 0.5,
            color=torch.rand(30, 3),
            id=torch.arange(30),
        )
    return trajectory
```

**Module-specific fixtures** defined at the top of individual test files. Pattern: small synthetic data sized for speed (10–30 points, 3–5 time steps). Example from `tests/test_dtw.py`:

```python
@pytest.fixture
def small_trajectory_pair():
    """Create very small trajectories for fast testing."""
    x = {i: zRegPointCloud(pos=torch.randn(10, 3), color=torch.rand(10, 3), id=torch.arange(10)) for i in range(3)}
    y = {i: zRegPointCloud(pos=torch.randn(10, 3), color=torch.rand(10, 3), id=torch.arange(10)) for i in range(3)}
    return x, y

@pytest.fixture
def sample_cost_matrix():
    """Create a sample cost matrix for testing DTW algorithms directly."""
    return torch.tensor([
        [1.0, 2.0, 3.0, 4.0],
        [2.0, 1.0, 2.0, 3.0],
        [3.0, 2.0, 1.0, 2.0],
        [4.0, 3.0, 2.0, 1.0],
    ])
```

---

## Mocking

**Framework:** `unittest.mock.MagicMock` used sparingly for device simulation only. No broad mocking framework (e.g., pytest-mock) in use.

**When mocking is used:** Only for simulating CUDA device presence when actual CUDA hardware is unavailable, in `tests/test_validation.py`:
```python
from unittest.mock import MagicMock

mock_tensor = MagicMock(spec=torch.Tensor)
mock_tensor.device = torch.device("cuda:0")
mock_tensor.__class__ = torch.Tensor

with pytest.raises(ValueError) as exc_info:
    _validate_tensors(cpu_tensor, mock_tensor, names=["source", "target"], check_finite=False)
```

**What is NOT mocked:** PyTorch tensors, `zRegPointCloud` objects, transformation objects, distance computations, file I/O (use `tempfile` instead). All math is computed with real values.

**Optional dependency guard:** `pytest.importorskip` used once for matplotlib in `tests/test_dtw.py`:
```python
def test_plot_saves_file(self, small_trajectory_pair):
    pytest.importorskip("matplotlib")
    # ... test proceeds only if matplotlib is installed
```

---

## CUDA / Device Handling

**Automatic CUDA skipping** configured in `tests/conftest.py`:
```python
def pytest_collection_modifyitems(config, items):
    """Modify test collection to skip CUDA tests when unavailable."""
    if not torch.cuda.is_available():
        skip_cuda = pytest.mark.skip(reason="CUDA not available")
        for item in items:
            if "cuda" in item.keywords:
                item.add_marker(skip_cuda)
```

**Per-test CUDA skipping** with `@pytest.mark.skipif`:
```python
@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA required")
def test_to_cuda(self):
    """Test moving point cloud to CUDA."""
```

Seen in `tests/test_transforms.py:373`, `tests/test_dataset.py:56`, `tests/test_cpd.py:617`.

---

## Pytest Configuration

**Markers** (`tests/conftest.py`):
```python
def pytest_configure(config):
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
```

Note: the `slow` marker is registered but not yet applied to any test in the current codebase.

**`addopts` in `setup.cfg`:**
```ini
[tool:pytest]
addopts =
    --cov zreg --cov-report term-missing
    --verbose
norecursedirs =
    dist
    build
    .tox
testpaths = tests
```

Coverage runs automatically on every `pytest` invocation (no explicit flag needed).

---

## Test Types

**Unit tests:** Isolate a single function, method, or behavior. Dominant pattern. Examples:
- `TestValidateTensors` in `tests/test_validation.py` — each test checks one error condition
- `TestBacktrace` in `tests/test_dtw.py` — each test exercises one path through `_backtrace`
- `TestEuclideanDistance` in `tests/test_distances.py` — shape, zero-self-distance, non-negativity tested separately

**Integration tests:** Test composed operations and workflows. Examples:
- `TestDTWCompute` — calls `compute()` which internally chains cost matrix, accumulated cost, and backtrace
- `TestSaveLoad` in `tests/test_dtw.py` — tests save/load round-trip preserving all result fields
- `TestGetAlignedTrajectory` — tests trajectory resampling using a computed warping path

**E2E tests:** Not used. The library has no CLI or user workflow entry point to test end-to-end.

---

## Common Patterns

**Error / exception testing:**
```python
with pytest.raises(ValueError, match="DTW warping path could not be traced"):
    dtw_obj._backtrace(acc)

with pytest.raises(RuntimeError):
    dtw_obj.get_warping_path()

# Check error message content
with pytest.raises(ValueError) as exc_info:
    _validate_tensors(t, names=["source"])
msg = str(exc_info.value)
assert "NaN" in msg
assert "source" in msg
```

The `match=` parameter to `pytest.raises` is used for critical messages (e.g., boundary condition errors in `tests/test_dtw.py`). Plain `pytest.raises(ExceptionType)` used when only the type matters.

**Tensor shape assertions:**
```python
assert result.shape == (100, 100)
assert accumulated.shape == sample_cost_matrix.shape
assert result.rotations.shape == (4, 3, 3)
```

**Floating-point comparisons:**
```python
assert torch.allclose(tf.rot, torch.eye(3))           # exact (identity)
assert torch.allclose(points, restored, atol=1e-5)    # round-trip with tolerance
assert torch.allclose(diagonal, torch.zeros(10), atol=1e-5)
```

**State / lifecycle testing** (before/after compute):
```python
def test_get_warping_path_before_compute(self, small_trajectory_pair):
    x, y = small_trajectory_pair
    dtw_obj = DynamicTimeWarping(x, y, distance_metric="euclidean")
    with pytest.raises(RuntimeError):
        dtw_obj.get_warping_path()

def test_get_warping_path_after_compute(self, small_trajectory_pair):
    x, y = small_trajectory_pair
    dtw_obj = DynamicTimeWarping(x, y, distance_metric="euclidean", downsample_method=None)
    dtw_obj.compute()
    path = dtw_obj.get_warping_path()
    assert len(path) > 0
    assert path[0] == (0, 0)
```

**Module export testing:**
```python
class TestExports:
    def test_exports(self):
        assert "DynamicTimeWarping" in dtw.__all__
        assert "DTWResult" in dtw.__all__

    def test_import_from_zreg(self):
        import zreg
        assert hasattr(zreg, "dtw")
        assert hasattr(zreg.dtw, "DynamicTimeWarping")
```

**Boundary / edge case testing** (explicit test class for edge cases):
```python
class TestDTWMetricsAndBoundaries:
    """Tests for DTW with additional distance metrics, windowed asymmetric inputs, and boundary conditions."""

    def test_boundary_single_timepoint_x(self):
        """Test DTW with single time point in x (1xN boundary)."""
        x = {0: zRegPointCloud(pos=torch.randn(10, 3))}
        y = {i: zRegPointCloud(pos=torch.randn(10, 3)) for i in range(3)}
        ...
        for i, j in result.warping_path:
            assert i == 0
```

---

## Coverage

**Requirements:** No minimum threshold enforced. No CI/CD pipeline present.

**Configuration** (`.coveragerc`):
- Branch coverage: enabled (`branch = True`)
- Source: `zreg` package
- Excluded patterns: `raise AssertionError`, `raise NotImplementedError`, `if 0:`, `if __name__ == .__main__.:`, `def __repr__`, `pragma: no cover`

**Run with HTML report:**
```bash
pytest --cov-report html    # Generates htmlcov/ directory
```

---

## Coverage Gaps

The following areas have limited or no direct test coverage based on source inspection:

- **`src/zreg/setup_log.py`** — logging configuration module; not covered by any test file
- **`src/zreg/pairwise_distance_matrix.py` MPI paths** — `mpi_distribute=True` branches require `mpi4py` and are not exercised by standard test runs
- **`src/zreg/downsampling.py` torch_cluster paths** — farthest-point sampling GPU acceleration skipped when `torch_cluster` not installed
- **`src/zreg/transforms.py` Open3D output path** — `return_o3d=True` branch of `transform_points_homogeneous` has limited test coverage
- **`src/zreg/distances/sw_varients.py`** — one variant marked BROKEN in source comments; behavior undefined/untested

---

*Testing analysis: 2026-04-10*
