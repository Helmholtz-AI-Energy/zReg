# Architecture Patterns

**Domain:** Scientific Python library consolidation (PyTorch point cloud registration)
**Researched:** 2026-04-08

## Recommended Architecture for Consolidation

The existing architecture is sound -- modular layers with clear data flow. Consolidation does not change the architecture. It adds **validation boundaries**, **error handling contracts**, and **test coverage** to the existing structure.

### Consolidation Component Map

```
PUBLIC API BOUNDARY (validation layer -- add here)
  |
  v
+-------------------+  +---------------------------+  +-------------------+
| cpd.registration  |  | pairwise_distance_matrix  |  | color_transfer    |
| cpd_registration  |  | .create_pairwise_...()    |  | .transfer_colors()|
+--------+----------+  +------------+--------------+  +--------+----------+
         |                          |                           |
         v                          v                           v
+-------------------+  +---------------------------+  +-------------------+
| transforms.*      |  | distances/                |  | cpd.expectation   |
| (internal layer)  |  | (internal layer)          |  | _step (internal)  |
+-------------------+  +---------------------------+  +-------------------+
         |                          |                           |
         v                          v                           v
+-------------------------------------------------------------------+
| utils.py, dataset.py  (foundation -- shared utilities)            |
+-------------------------------------------------------------------+
```

### Component Boundaries

| Component | Responsibility | Communicates With | Validation Needed |
|-----------|---------------|-------------------|-------------------|
| `cpd.registration()` / `cpd_registration()` | Public entry: run CPD registration | transforms, utils | YES -- NaN/inf, device, shape |
| `pairwise_distance_matrix.create_pairwise_distance_matrix()` | Public entry: compute distance matrix | distances, cpd, downsampling, MPI | YES -- NaN/inf, device, metric name |
| `color_transfer.transfer_colors()` | Public entry: transfer cell types | cpd EstepResult, dataset | YES -- method name, shape, empty checks |
| `dtw.DynamicTimeWarping.compute()` | Public entry: temporal alignment | pairwise_distance_matrix | YES -- path reconstruction guards |
| `transforms.transform_points_homogeneous()` | Public entry: apply transform | dataset, Open3D | YES -- homogeneous coordinate div-by-zero |
| `dataset.load_data_from_tracklets()` | Public entry: data loading | scipy, torch | YES -- file exists, data shape |
| `downsampling.*` | Public entry: point cloud reduction | torch_cluster, Open3D | YES -- backend availability, empty input |
| `distances/*` | Internal: metric computation | utils | NO -- validated upstream |
| `utils.*` | Internal: kernels, normalization | torch | NO -- validated upstream |

## Where Validation Should Be Added

### Principle: Validate at the public API boundary, not internally

Add validation at the 7 public entry points listed above. Internal functions (`utils.py`, `distances/`) should NOT validate -- they trust that callers have already checked. This avoids redundant checks in hot loops (distance calculations run thousands of times in a single registration).

### Validation Functions to Create

Add a `src/zreg/validation.py` module with reusable validators:

```python
# src/zreg/validation.py

def validate_point_cloud_tensor(tensor: torch.Tensor, name: str = "points") -> None:
    """Check tensor is 2D, finite, on consistent device."""
    if tensor.dim() != 2:
        raise ValueError(f"{name} must be 2D tensor, got {tensor.dim()}D")
    if tensor.shape[1] not in (2, 3):
        raise ValueError(f"{name} must have 2 or 3 columns, got {tensor.shape[1]}")
    if torch.isnan(tensor).any():
        raise ValueError(f"{name} contains NaN values")
    if torch.isinf(tensor).any():
        raise ValueError(f"{name} contains infinite values")

def validate_device_consistency(*tensors: torch.Tensor, names: list[str] = None) -> None:
    """Check all tensors are on the same device."""
    devices = [t.device for t in tensors]
    if len(set(str(d) for d in devices)) > 1:
        detail = ", ".join(f"{n}={d}" for n, d in zip(names or range(len(tensors)), devices))
        raise ValueError(f"All tensors must be on same device, got: {detail}")

def validate_homogeneous_divisor(homogeneous_coord: torch.Tensor, atol: float = 1e-7) -> None:
    """Check homogeneous coordinate is not near-zero before division."""
    if (homogeneous_coord.abs() < atol).any():
        raise ValueError(
            "Homogeneous coordinate near zero -- point cloud has degenerate coordinates. "
            "Normalize points before transformation."
        )
```

### Where Each Validator Gets Called

| Validator | Called In | Reason |
|-----------|----------|--------|
| `validate_point_cloud_tensor` | `cpd.registration()`, `create_pairwise_distance_matrix()`, `transfer_colors()` | Catch bad data before expensive computation |
| `validate_device_consistency` | `cpd.registration()`, `transform_points_homogeneous()` | Prevent cryptic CUDA errors |
| `validate_homogeneous_divisor` | `transform_points_homogeneous()` (line 78) | Prevent numerical instability |

## Data Flow

### Registration Workflow (with validation points marked)

```
User Input
  |
  v
[VALIDATE] cpd_registration(source_dict, target_dict, tf_type_name)
  |         - validate source["pos"], target["pos"] tensors
  |         - validate device consistency
  |         - validate tf_type_name is known
  |
  v
CPD.__init__ --> set_source, set transformation type
  |
  v
CPD.registration(target, maxiter, tol)
  |
  +---> E-step: compute posterior probabilities
  |       (no validation -- internal hot path)
  |
  +---> M-step: update transformation parameters
  |       [GUARD] sigma2 > min_sigma2 (prevent collapse)
  |       [GUARD] scale factor within bounds (RigidCPD)
  |
  +---> Check convergence
  |
  v
MstepResult(transformation, sigma2, q)
  |
  v
[VALIDATE] transform_points_homogeneous(points, matrix)
  |         - validate homogeneous divisor
  |
  v
Transformed points (zRegPointCloud)
```

### Distance Matrix Workflow (with validation points marked)

```
User Input
  |
  v
[VALIDATE] create_pairwise_distance_matrix(traj1, traj2, distance_metric, ...)
  |         - validate trajectory dicts contain "pos" keys
  |         - validate distance_metric string is known
  |         - validate device consistency across trajectory
  |
  v
Sanitize distance function (string -> callable)
  |
  v
For each (i, j) pair:
  |  downsample -> compute distance
  |  (no per-pair validation -- validated upstream)
  |
  v
Distance matrix tensor
```

## Patterns to Follow

### Pattern 1: Boundary Validation with Early Exit

**What:** Validate inputs at public API entry, raise informative errors immediately.
**When:** Every public function that accepts user data.
**Example:**
```python
def registration(self, target: torch.Tensor, maxiter: int = 150, ...):
    validate_point_cloud_tensor(target, name="target")
    validate_device_consistency(self._source, target, names=["source", "target"])
    # ... proceed with computation
```

### Pattern 2: Guard Clauses for Numerical Stability

**What:** Add bounds checks around known numerical danger zones without changing algorithm logic.
**When:** Inside iterative algorithms where values can degenerate.
**Example:**
```python
# In CPD M-step, after computing sigma2:
MIN_SIGMA2 = 1e-10
if sigma2 < MIN_SIGMA2:
    log.warning(f"sigma2 collapsed to {sigma2:.2e}, clamping to {MIN_SIGMA2}")
    sigma2 = MIN_SIGMA2
```

### Pattern 3: Enum-Based Method Dispatch (Replace String Matching)

**What:** Use the existing `ColorTransferMethod` class properly for dispatch instead of raw string comparison.
**When:** Functions that select behavior based on a string parameter.
**Example:**
```python
_DISPATCH = {
    ColorTransferMethod.NEAREST_NEIGHBOR: _transfer_colors_nearest_neighbor,
    ColorTransferMethod.CPD_WEIGHTED: _transfer_colors_cpd_weighted,
    ColorTransferMethod.KNN_VOTING: _transfer_colors_knn_voting,
    ColorTransferMethod.GAUSSIAN_KERNEL: _transfer_colors_gaussian_kernel,
}

def transfer_colors(source, target, method="nearest_neighbor", **kwargs):
    handler = _DISPATCH.get(method)
    if handler is None:
        valid = ", ".join(_DISPATCH.keys())
        raise ValueError(f"Unknown method '{method}'. Valid: {valid}")
    return handler(source, target, **kwargs)
```

## Anti-Patterns to Avoid

### Anti-Pattern 1: Validating Inside Hot Loops

**What:** Adding NaN checks inside `distances/general.py` or `utils.py` kernel functions.
**Why bad:** These functions are called thousands of times per registration. Validation overhead adds up. Data was already validated at the entry point.
**Instead:** Validate once at the public API boundary.

### Anti-Pattern 2: Silent Fallback Without Logging

**What:** Silently falling back to CPU or a different backend when the requested one is unavailable.
**Why bad:** User gets different behavior without knowing. Already a problem in `downsampling.py` with torch_cluster fallback.
**Instead:** Log a WARNING with the fallback and why. The current codebase does this sometimes but not consistently.

### Anti-Pattern 3: Assert for User Input Validation

**What:** Using `assert` statements to validate user-provided data.
**Why bad:** Assertions are stripped in optimized mode (`python -O`). Already present in `utils.py` line 149.
**Instead:** Use `if ... raise ValueError(...)` for user-facing validation. Keep `assert` only for internal invariants that indicate programmer error.

## Test Organization for Scientific Code

### Current State

The existing test suite mirrors modules 1:1 (good). Tests use class-based grouping within files (good). Shared fixtures are in `conftest.py` (good). However, tests are primarily **happy-path correctness checks** -- they verify shapes and basic functionality but miss:

- Numerical edge cases (near-zero, NaN, inf, degenerate inputs)
- Error path testing (does the right exception get raised?)
- Property-based testing (mathematical invariants that should always hold)

### Recommended Test Categories

Organize tests within each existing file using these categories:

```python
# test_cpd.py

class TestRigidCPD:
    """Happy-path correctness tests (existing)."""
    ...

class TestRigidCPDEdgeCases:
    """Numerical edge cases and boundary conditions."""
    def test_nearly_identical_point_clouds(self): ...
    def test_extreme_scale_difference(self): ...
    def test_single_point_cloud(self): ...
    def test_very_large_point_cloud_values(self): ...

class TestRigidCPDValidation:
    """Input validation -- do we reject bad input correctly?"""
    def test_nan_in_source_raises(self): ...
    def test_inf_in_target_raises(self): ...
    def test_device_mismatch_raises(self): ...
    def test_wrong_dimensions_raises(self): ...

class TestRigidCPDProperties:
    """Mathematical properties that must hold."""
    def test_registration_reduces_distance(self): ...  # (already exists)
    def test_identity_transform_for_same_clouds(self): ...
    def test_rigid_transform_preserves_distances(self): ...
```

### Test Fixtures to Add to conftest.py

```python
@pytest.fixture
def nan_point_cloud():
    """Point cloud with NaN values for validation testing."""
    pts = torch.randn(50, 3)
    pts[10, 1] = float('nan')
    return pts

@pytest.fixture
def inf_point_cloud():
    """Point cloud with infinite values for validation testing."""
    pts = torch.randn(50, 3)
    pts[5, 0] = float('inf')
    return pts

@pytest.fixture
def degenerate_point_cloud():
    """All points at the same location."""
    return torch.zeros(50, 3)

@pytest.fixture
def extreme_scale_point_cloud():
    """Point cloud with very large coordinate values."""
    return torch.randn(50, 3) * 1e6
```

### Test File Structure (Keep Existing, Add Categories)

```
tests/
  conftest.py              # Shared fixtures (expand with edge case fixtures)
  test_cpd.py              # Add EdgeCases, Validation, Properties classes
  test_distances.py        # Add EdgeCases, Validation classes
  test_transforms.py       # Add EdgeCases, Validation, Properties classes
  test_dtw.py              # Add EdgeCases (path reconstruction), Validation
  test_color_transfer.py   # Add EdgeCases (empty, single point), Validation
  test_pairwise_distance_matrix.py  # Add Validation class
  test_downsampling.py     # Add EdgeCases (empty input), Validation
  test_dataset.py          # Keep as-is
  test_utils.py            # Keep as-is
  test_validation.py       # NEW: test the validation module itself
```

## Suggested Ordering for Consolidation Work

The consolidation should follow this order, based on dependency analysis:

### Phase 1: Foundation (bugs + validation infrastructure)

**Rationale:** Fix bugs first so that new tests verify correct behavior, not broken behavior. Add validation module so subsequent work can use it.

1. **Create `validation.py`** -- the reusable validators. This is a leaf module with no dependencies on other zReg code.
2. **Fix known bugs** (MaxSWD, RigidCPD scale, GSWD degree, DTW path, homogeneous coords) -- these must be fixed before writing tests that assert correct behavior.
3. **Clean up tech debt** (Python 3.8 compat, logging config, ASWD file handling) -- small, low-risk changes.

**Build order rationale:** `validation.py` has zero dependencies on existing code. Bug fixes touch individual modules independently. Tech debt cleanup is isolated per-file.

### Phase 2: Hardening (wire validation into public APIs)

**Rationale:** Now that validators exist and bugs are fixed, wire them into entry points.

1. **Add validation calls** to the 7 public entry points (see table above).
2. **Add numerical guards** (sigma2 bounds in CPD, homogeneous divisor check in transforms).
3. **Improve error messages** (device mismatch, invalid method strings, missing dependencies).
4. **Apply enum/strategy pattern** for color transfer dispatch.

**Build order rationale:** Validation must exist (Phase 1) before it can be wired in. Each entry point can be hardened independently.

### Phase 3: Test coverage

**Rationale:** Now that code is correct (Phase 1) and robust (Phase 2), write tests that verify both.

1. **Add edge case tests** for CPD (numerical stability, extreme scales).
2. **Add DTW path reconstruction tests** (multiple metrics, windowed, boundaries).
3. **Add transform composition tests** (3+ transforms, matrix property checks).
4. **Add device handling tests** (GPU/CPU, mixed device).
5. **Add color transfer edge case tests** (empty, single point, mismatched dims).
6. **Add validation tests** (verify each validator rejects bad input correctly).

**Build order rationale:** Tests depend on both the fix (Phase 1) and the validation (Phase 2). Testing validation error paths requires validation to be wired in.

### Phase 4: Performance quick wins

**Rationale:** Performance improvements are lowest risk when the test suite is comprehensive.

1. **Cache normalized point clouds** in RBF kernel (remove redundant normalization).
2. **Fix MPI communication** to send only computed rows.
3. **Profile and document** remaining bottlenecks for future work.

**Build order rationale:** Performance changes are safest last, when tests can catch regressions.

### Dependency Graph

```
Phase 1: Foundation
  validation.py (new, no deps)
  bug fixes (independent per module)
  tech debt cleanup (independent per file)
       |
       v
Phase 2: Hardening
  wire validation into entry points (depends on validation.py)
  numerical guards (depends on bug fixes)
  error messages + dispatch patterns (independent)
       |
       v
Phase 3: Test Coverage
  all test categories (depends on correct + validated code)
       |
       v
Phase 4: Performance
  caching, MPI fix (safest with full test suite)
```

## Scalability Considerations

Not a primary concern for consolidation -- the architecture does not change. However, validation should be designed to not impact performance at scale:

| Concern | Consolidation Impact | Approach |
|---------|---------------------|----------|
| Validation overhead | NaN/inf checks on large tensors | Use `torch.isnan().any()` and `torch.isinf().any()` -- O(n) but single-pass, no allocation |
| Device checks | Comparing device strings | O(1), negligible |
| Sigma2 bounds check | Single comparison per iteration | O(1), negligible |

## Sources

- Codebase analysis: `src/zreg/` (13 source files), `tests/` (10 test files)
- Existing architecture: `.planning/codebase/ARCHITECTURE.md`
- Identified concerns: `.planning/codebase/CONCERNS.md`
- Project scope: `.planning/PROJECT.md`
- PyTorch validation patterns: based on torch.nn module conventions (validate in forward(), not in internal methods)
- pytest organization: follows existing project conventions (class-based grouping, conftest fixtures)

---

*Architecture analysis: 2026-04-08*
