# Feature Landscape

**Domain:** Scientific Python library consolidation (GPU-accelerated 3D point cloud registration)
**Researched:** 2026-04-08
**Overall Confidence:** MEDIUM -- based on established patterns from scipy, scikit-learn, probreg, pytorch3d, and PyTorch ecosystem conventions. No web search available; relying on training data for mature library patterns which have been stable for years.

## Table Stakes

Features users expect from a robust scientific Python library. Missing any of these means the library feels unfinished or untrustworthy.

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| Input validation at public API boundaries | scipy, scikit-learn all validate inputs; silent NaN propagation is the #1 source of hard-to-debug scientific computing bugs | Low | Add `torch.isfinite()` checks on tensor inputs to `registration()`, `create_pairwise_distance_matrix()`, distance forward methods. Raise `ValueError` with message naming the offending argument |
| Device consistency checks | PyTorch libraries that mix CPU/GPU tensors produce cryptic CUDA errors; users expect clear "tensor A is on cuda:0 but tensor B is on cpu" messages | Low | Add a `_check_device_consistency(*tensors)` utility. Call at entry points in CPD, transforms, distances |
| dtype consistency checks | Mixing float32/float64 silently degrades precision or raises runtime errors | Low | Bundle with device checks: `_check_tensor_compat(*tensors, check_device=True, check_dtype=True)` |
| All public code paths tested | Any untested path is a latent bug. Mature libraries target >90% coverage on core algorithms | Medium | CPD numerical stability, DTW path reconstruction, transform composition, device handling, color transfer edge cases -- all identified gaps in CONCERNS.md |
| Known bugs fixed | Shipping known-broken public API (MaxSWD "BROKEN IN BACKWARDS") destroys trust | Medium | Fix MaxSWD, RigidCPD scale, GSWD degree default, DTW path reconstruction, homogeneous coordinate instability |
| Informative error messages | scikit-learn is the gold standard: errors name the parameter, expected type/shape, and what was received | Low | Replace bare `TypeError`/`ValueError` with messages like `"Expected source to be a tensor of shape (n, 3), got shape {source.shape}"` |
| Consistent logging (not hardcoded) | Every mature library lets users control verbosity. Hardcoded INFO logging pollutes user output | Low | `logging.getLogger("zreg").setLevel()` pattern; accept env var `ZREG_LOG_LEVEL` or init parameter. Never configure root logger |
| Clean file I/O (no hardcoded paths, no leaked temp files) | ASWD writing to "projs_history.txt" is a race condition and cleanup hazard | Low | Use `tempfile.NamedTemporaryFile` with process ID or context manager pattern |
| Remove dead compatibility code | Python 3.8 conditional imports when minimum is 3.9 confuses readers and adds maintenance burden | Low | Straightforward removal |
| Docstrings on all public API | NumPy-style docstrings are the convention; already mostly followed but needs completeness audit | Low | Already convention per CONVENTIONS.md; ensure 100% coverage on `__all__` exports |
| Shape validation on tensor inputs | Point clouds must be (n, 3), transform matrices (4, 4), etc. Wrong shapes produce nonsense results silently | Low | Add `assert tensor.ndim == 2 and tensor.shape[1] == 3` style checks, raising `ValueError` |
| Deprecation warnings before API changes | If any fix changes behavior, use `warnings.warn(..., DeprecationWarning)` | Low | Standard Python pattern; scipy uses this extensively |

## Differentiators

Features that go beyond minimum expectations. Not required for a robust library, but signal maturity and care.

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| Convergence diagnostics for CPD | Log/return iteration count, sigma2 trajectory, likelihood trajectory. Lets users understand why registration failed | Medium | Add `ConvergenceInfo` namedtuple to registration result. scikit-learn's `n_iter_` attribute pattern |
| sigma2 bounds and safeguards | Prevent numerical explosion when sigma2 approaches zero in CPD loop | Medium | Clamp sigma2 to `[eps, initial_sigma2]`; warn when hitting bounds. Directly addresses CONCERNS.md fragility |
| Transform validation after composition | Check determinant > 0 (no reflection), condition number reasonable (no near-singular), orthogonality for rigid | Medium | `CombinedTransformation.validate()` method. Catch accumulated floating-point drift |
| Parametric/property-based testing with Hypothesis | Generate random point clouds, transformations, edge cases automatically. Catches bugs that hand-written tests miss | Medium | `hypothesis` + `hypothesis[numpy]` strategies. Best for: transform composition properties (associativity, identity), distance metric properties (non-negativity, symmetry, triangle inequality) |
| Enum-based method dispatch for color transfer | Replace string matching with `ColorTransferMethod` enum. Type-safe, IDE-autocompletes, impossible to typo | Low | `class ColorTransferMethod(str, Enum)` so strings still work for backwards compat |
| Backend logging for downsampling | Log which backend (torch_cluster vs Open3D vs scipy) was selected and why | Low | One `log.info()` call at selection point. Users currently have no idea which backend runs |
| Performance regression tests | Ensure consolidation changes don't accidentally slow down critical paths | Medium | `pytest-benchmark` on core operations (CPD registration, SWD computation, pairwise distance). Store baselines |
| Structured result objects | Replace raw tuples/dicts with dataclasses or named tuples for all return values | Medium | Already using `DTWResult`, `EstepResult`. Extend pattern to registration results, distance results |
| Type stubs or py.typed marker | Enable mypy/pyright checking for downstream users | Low | Add `py.typed` marker file, ensure type hints are complete |
| GPU memory usage documentation | Document expected memory footprint for different point cloud sizes | Low | Add to docstrings: "For n=100k points, expects ~X GB GPU memory" |

## Anti-Features

Features to explicitly NOT build during consolidation. Each has been considered and rejected.

| Anti-Feature | Why Avoid | What to Do Instead |
|--------------|-----------|-------------------|
| New distance metrics or registration algorithms | Scope creep. Consolidation means fixing what exists, not adding capabilities | Track in PROJECT.md "Out of Scope" for future milestone |
| Full MPI refactoring | Beyond quick wins. Current bandaid fix (send only computed rows) is the right scope | Fix the row communication issue only; defer hierarchical patterns |
| Replacing Open3D/torch_cluster with pure PyTorch | Major architectural change disguised as cleanup. Different behavior, different performance profile | Improve error handling around these dependencies instead |
| Alignment quality metrics (TRE, chamfer distance) | New feature, not consolidation. PROJECT.md explicitly marks out of scope | Add as future milestone |
| 100% test coverage as a gate | Diminishing returns past ~90% on core paths. Chasing 100% leads to brittle tests on implementation details | Target high coverage on public API and critical algorithms; accept gaps in internal plumbing |
| Comprehensive benchmarking suite | Building a proper benchmark suite is its own project. Quick perf regression tests (differentiator above) are sufficient | Use `pytest-benchmark` for key operations only |
| Rewriting to use dataclasses everywhere | Changing `zRegPointCloud` from TypedDict to dataclass would break every consumer | Keep TypedDict; add validation at boundaries instead |
| Batch/vectorized pairwise distance | Performance optimization beyond quick wins. Requires architectural changes to distance function signatures | Out of scope per PROJECT.md |
| Uncertainty quantification | New analytical capability, not a robustness improvement | Future milestone |
| Sparse matrix storage | Architectural change for scaling, not consolidation | Future milestone |

## Feature Dependencies

```
Input validation utilities --> All bug fixes (fixes depend on validation helpers)
Device/dtype check utility --> CPD fixes, transform fixes, distance fixes
Fix MaxSWD implementation --> MaxSWD tests
Fix RigidCPD scale --> CPD numerical stability tests
Fix GSWD degree default --> Distance metric tests
Fix DTW path reconstruction --> DTW path tests
Fix homogeneous coordinate instability --> Transform composition tests
Enum for color transfer methods --> Color transfer edge case tests
Configurable logging --> All modules (remove hardcoded setup first)
Remove Python 3.8 compat --> No dependencies (do first as quick win)
Clean ASWD file handling --> ASWD tests
Convergence diagnostics --> sigma2 bounds (diagnostics make bounds visible)
```

## MVP Recommendation

The consolidation MVP (minimum for the library to be "trustworthy") should prioritize in this order:

### Priority 1: Foundation (unblocks everything else)
1. **Input validation utility** (`_validate_tensors()` with NaN/inf, shape, device, dtype checks)
2. **Remove Python 3.8 compat code** (trivial, zero risk)
3. **Configurable logging** (stops polluting user output)

### Priority 2: Fix known bugs
4. **Fix MaxSWD** (currently marked broken in source)
5. **Fix RigidCPD scale handling**
6. **Fix GSWD degree default**
7. **Fix DTW path reconstruction**
8. **Fix homogeneous coordinate instability**
9. **Fix ASWD file handling** (tempfile + cleanup)

### Priority 3: Close test gaps
10. **CPD numerical stability tests**
11. **DTW path reconstruction tests**
12. **Transform composition tests**
13. **Device handling tests**
14. **Color transfer edge case tests**

### Priority 4: Code quality improvements
15. **Enum-based color transfer dispatch**
16. **Fix MPI row communication** (quick win)
17. **Cache normalized point clouds for RBF kernel**
18. **Convergence diagnostics for CPD**

**Defer to future:** Property-based testing, performance benchmarks, py.typed marker, structured result objects. These are quality-of-life improvements that don't affect correctness.

## Complexity Budget

| Category | Item Count | Estimated Effort | Risk |
|----------|-----------|-----------------|------|
| Table stakes | 12 items | ~3-5 days | Low -- well-understood patterns |
| Bug fixes | 6 bugs | ~2-3 days | Medium -- MaxSWD may need algorithm research |
| Test gaps | 5 areas | ~2-3 days | Low -- testing existing behavior |
| Differentiators | 10 items | ~3-5 days each subset | Low -- optional, pick as time allows |

## Sources

- Training data knowledge of scipy, scikit-learn, probreg, pytorch3d, kornia validation patterns (MEDIUM confidence -- stable patterns unlikely to have changed)
- Direct codebase analysis of zReg source and CONCERNS.md (HIGH confidence)
- PyTorch device/dtype management conventions from PyTorch documentation (MEDIUM confidence)
- scikit-learn input validation patterns (`check_array`, `check_X_y`) as gold standard (HIGH confidence -- these patterns are years old and stable)
